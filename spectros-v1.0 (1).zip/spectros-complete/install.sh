#!/bin/sh
# ═══════════════════════════════════════════════════════════════════
#  SpectrOS — Instal·lador complet
#  ArCom Corporation — FreeBSD arm64 — QEMU
#
#  Executa com a root:  sh install.sh
# ═══════════════════════════════════════════════════════════════════

# ── Colors ────────────────────────────────────────────────────────
R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
B='\033[0;34m'; C='\033[0;36m'; NC='\033[0m'; BO='\033[1m'

ok()    { printf "  ${G}✔${NC}  $1\n"; }
warn()  { printf "  ${Y}⚠${NC}  $1\n"; }
error() { printf "  ${R}✘  ERROR: $1${NC}\n"; exit 1; }
step()  { printf "\n${B}${BO}▶ Pas $1 — $2${NC}\n"; }
info()  { printf "  ${C}→${NC}  $1\n"; }

SCRIPT_DIR="$(dirname "$(realpath "$0")")"

# ── Capçalera ─────────────────────────────────────────────────────
clear
printf "${B}${BO}"
printf "╔══════════════════════════════════════════════════════╗\n"
printf "║         SpectrOS — Instal·lador complet v1.0         ║\n"
printf "║              ArCom Corporation                       ║\n"
printf "║         FreeBSD arm64 · QEMU · GTK3 · XFCE          ║\n"
printf "╚══════════════════════════════════════════════════════╝\n"
printf "${NC}\n"

# ── Comprovar root ────────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
    error "Cal executar com a root: sh install.sh"
fi
ok "Executant com a root"

# ── Demanar nom d'usuari ──────────────────────────────────────────
printf "\n${Y}Introduïu el nom d'usuari principal (no root): ${NC}"
read -r MAIN_USER
if [ -z "$MAIN_USER" ]; then
    warn "No heu introduït cap usuari. Es crearà l'usuari 'spectros'."
    MAIN_USER="spectros"
fi

# Crear usuari si no existeix
if ! id "$MAIN_USER" >/dev/null 2>&1; then
    info "Creant usuari '$MAIN_USER'..."
    pw useradd -n "$MAIN_USER" -m -s /bin/sh -G wheel,video,operator \
        || error "No s'ha pogut crear l'usuari"
    printf "${Y}Introduïu la contrasenya per a '$MAIN_USER': ${NC}\n"
    passwd "$MAIN_USER"
    ok "Usuari '$MAIN_USER' creat"
else
    ok "Usuari '$MAIN_USER' ja existeix"
fi

MAIN_HOME="$(eval echo ~${MAIN_USER})"

# Afegir als grups necessaris
pw groupmod wheel    -m "$MAIN_USER" 2>/dev/null || true
pw groupmod video    -m "$MAIN_USER" 2>/dev/null || true
pw groupmod operator -m "$MAIN_USER" 2>/dev/null || true
ok "Grups: wheel, video, operator"

# ── Sudo sense contrasenya ────────────────────────────────────────
pkg info sudo >/dev/null 2>&1 || pkg install -y sudo >/dev/null 2>&1
mkdir -p /usr/local/etc/sudoers.d
echo "${MAIN_USER} ALL=(ALL) NOPASSWD: ALL" \
    > /usr/local/etc/sudoers.d/spectros
chmod 440 /usr/local/etc/sudoers.d/spectros
ok "sudo sense contrasenya per a '$MAIN_USER'"


# ════════════════════════════════════════════════════════════════
# PAS 1 — Paquets
# ════════════════════════════════════════════════════════════════
step 1 "Instal·lant paquets (pot trigar uns minuts...)"

pkg update -f >/dev/null 2>&1 || warn "No s'ha pogut actualitzar el repositori"

pkg_get() {
    if ! pkg info "$1" >/dev/null 2>&1; then
        info "Instal·lant $1..."
        pkg install -y "$1" >/dev/null 2>&1 && ok "$1" \
            || warn "$1 no disponible (continuant)"
    else
        ok "$1 (ja instal·lat)"
    fi
}

pkg_get xorg
pkg_get xf86-video-vesa
pkg_get xf86-video-fbdev
pkg_get xf86-input-keyboard
pkg_get xf86-input-mouse
pkg_get xf86-input-evdev
pkg_get xfce
pkg_get xfce4-goodies
pkg_get xfce4-terminal
pkg_get lightdm
pkg_get lightdm-gtk-greeter
pkg_get dbus
pkg_get polkit
pkg_get python3
pkg_get py311-gobject3
pkg_get gtk3
pkg_get adwaita-icon-theme
pkg_get xdg-utils
pkg_get xdg-user-dirs
pkg_get bash
pkg_get nano


# ════════════════════════════════════════════════════════════════
# PAS 2 — Xorg per a QEMU arm64
# ════════════════════════════════════════════════════════════════
step 2 "Configurant Xorg per a QEMU arm64"

mkdir -p /usr/local/etc/X11/xorg.conf.d

cat > /usr/local/etc/X11/xorg.conf.d/10-video.conf << 'EOF'
Section "Device"
    Identifier  "Card0"
    Driver      "vesa"
EndSection

Section "Screen"
    Identifier  "Screen0"
    Device      "Card0"
    DefaultDepth 24
    SubSection "Display"
        Depth    24
        Modes    "1024x768" "800x600" "640x480"
    EndSubSection
EndSection
EOF
ok "xorg.conf.d/10-video.conf (driver vesa)"

# Permisos dispositius gràfics
chmod 666 /dev/fb0    2>/dev/null || true
chmod 666 /dev/ttyv0  2>/dev/null || true
chmod -R 666 /dev/dri 2>/dev/null || true


# ════════════════════════════════════════════════════════════════
# PAS 3 — Apps SpectrOS
# ════════════════════════════════════════════════════════════════
step 3 "Instal·lant apps SpectrOS"

APP_DIR="/usr/local/bin/spectros"
mkdir -p "$APP_DIR"

for app in spectros-config spectros-filemanager spectros-shop spectros-updater; do
    src="$SCRIPT_DIR/apps/$app/$app.py"
    if [ -f "$src" ]; then
        cp "$src" "$APP_DIR/$app.py"
        chmod 755 "$APP_DIR/$app.py"
        ok "$app"
    else
        warn "$app no trobat (continua)"
    fi
done

[ -f "$SCRIPT_DIR/apps/version.json" ] && \
    cp "$SCRIPT_DIR/apps/version.json" "$APP_DIR/" && ok "version.json"


# ════════════════════════════════════════════════════════════════
# PAS 4 — Icones menú i escriptori
# ════════════════════════════════════════════════════════════════
step 4 "Configurant icones"

MENU_DIR="/usr/local/share/applications"
DESK_DIR="$MAIN_HOME/Desktop"
mkdir -p "$MENU_DIR" "$DESK_DIR"

for app in spectros-config spectros-filemanager spectros-shop spectros-updater; do
    src="$SCRIPT_DIR/apps/$app.desktop"
    if [ -f "$src" ]; then
        cp "$src" "$MENU_DIR/$app.desktop"
        chmod 644 "$MENU_DIR/$app.desktop"
        cp "$src" "$DESK_DIR/$app.desktop"
        chmod 755 "$DESK_DIR/$app.desktop"
        chown "$MAIN_USER" "$DESK_DIR/$app.desktop"
        ok "$app.desktop"
    fi
done

update-desktop-database "$MENU_DIR" 2>/dev/null || true


# ════════════════════════════════════════════════════════════════
# PAS 5 — LightDM
# ════════════════════════════════════════════════════════════════
step 5 "Configurant LightDM"

mkdir -p /usr/local/etc/lightdm

cat > /usr/local/etc/lightdm/lightdm.conf << 'EOF'
[Seat:*]
greeter-session=lightdm-gtk-greeter
user-session=xfce
allow-guest=false
EOF

cat > /usr/local/etc/lightdm/lightdm-gtk-greeter.conf << 'EOF'
[greeter]
theme-name=Adwaita
icon-theme-name=Adwaita
font-name=Sans 11
xft-dpi=96
indicators=~host;~spacer;~clock;~spacer;~session;~power
clock-format=%H:%M  —  %A %d %B %Y
background=#F0F2F8
EOF

ok "LightDM configurat (greeter GTK)"


# ════════════════════════════════════════════════════════════════
# PAS 6 — XFCE
# ════════════════════════════════════════════════════════════════
step 6 "Configurant XFCE"

# .xinitrc
cat > "$MAIN_HOME/.xinitrc" << 'EOF'
#!/bin/sh
eval $(dbus-launch --sh-syntax)
exec startxfce4
EOF
chown "$MAIN_USER" "$MAIN_HOME/.xinitrc"
chmod 755 "$MAIN_HOME/.xinitrc"
ok ".xinitrc"

# Carpetes estàndard
for dir in Desktop Documents Downloads Music Pictures Videos; do
    mkdir -p "$MAIN_HOME/$dir"
    chown "$MAIN_USER" "$MAIN_HOME/$dir"
done
ok "Carpetes d'usuari"

# Configuració sessió XFCE
XFCE_DIR="$MAIN_HOME/.config/xfce4/xfconf/xfce-perchannel-xml"
mkdir -p "$XFCE_DIR"
cat > "$XFCE_DIR/xfce4-session.xml" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-session" version="1.0">
  <property name="general" type="empty">
    <property name="FailsafeSessionName" type="string" value="Failsafe"/>
    <property name="SessionName" type="string" value="Default"/>
  </property>
  <property name="sessions" type="empty">
    <property name="Failsafe" type="empty">
      <property name="IsFailsafe" type="bool" value="true"/>
      <property name="Count" type="int" value="4"/>
      <property name="Client0_Command" type="array">
        <value type="string" value="xfwm4"/>
      </property>
      <property name="Client1_Command" type="array">
        <value type="string" value="xfce4-panel"/>
      </property>
      <property name="Client2_Command" type="array">
        <value type="string" value="xfdesktop"/>
      </property>
      <property name="Client3_Command" type="array">
        <value type="string" value="Thunar --daemon"/>
      </property>
    </property>
  </property>
</channel>
EOF
chown -R "$MAIN_USER" "$MAIN_HOME/.config"
ok "Sessió XFCE"


# ════════════════════════════════════════════════════════════════
# PAS 7 — rc.conf permanent
# ════════════════════════════════════════════════════════════════
step 7 "Activant serveis permanents (rc.conf)"

set_rc() {
    key="$1"; val="$2"
    if grep -q "^${key}=" /etc/rc.conf 2>/dev/null; then
        sed -i '' "s|^${key}=.*|${key}=${val}|" /etc/rc.conf
    else
        echo "${key}=${val}" >> /etc/rc.conf
    fi
}

set_rc dbus_enable    '"YES"'
set_rc polkitd_enable '"YES"'
set_rc hald_enable    '"YES"'
set_rc moused_enable  '"YES"'
set_rc lightdm_enable '"YES"'

ok "dbus, polkitd, hald, moused, lightdm activats"

# Boot silenciós
grep -q "^boot_mute=" /boot/loader.conf 2>/dev/null \
    && sed -i '' 's|^boot_mute=.*|boot_mute="YES"|' /boot/loader.conf \
    || echo 'boot_mute="YES"' >> /boot/loader.conf
ok "Boot silenciós"


# ════════════════════════════════════════════════════════════════
# PAS 8 — Test Xorg
# ════════════════════════════════════════════════════════════════
step 8 "Comprovant Xorg"

service dbus start 2>/dev/null || true
sleep 2

XORG_OK=false
DRIVER_USED="vesa"

# Test amb vesa
timeout 8 Xorg -noreset -logfile /tmp/xorg-test.log :99 >/dev/null 2>&1 &
XPID=$!
sleep 5
if kill -0 $XPID 2>/dev/null; then
    kill $XPID 2>/dev/null
    ok "Xorg OK amb driver vesa"
    XORG_OK=true
    DRIVER_USED="vesa"
else
    warn "vesa ha fallat, provant fbdev..."
    cat > /usr/local/etc/X11/xorg.conf.d/10-video.conf << 'EOF'
Section "Device"
    Identifier  "Card0"
    Driver      "fbdev"
EndSection
EOF
    timeout 8 Xorg -noreset -logfile /tmp/xorg-test2.log :99 >/dev/null 2>&1 &
    XPID2=$!
    sleep 5
    if kill -0 $XPID2 2>/dev/null; then
        kill $XPID2 2>/dev/null
        ok "Xorg OK amb driver fbdev"
        XORG_OK=true
        DRIVER_USED="fbdev"
    else
        warn "Cap driver ha funcionat en el test."
        warn "Revisa: cat /tmp/xorg-test.log | grep '(EE)'"
    fi
fi


# ════════════════════════════════════════════════════════════════
# RESUM
# ════════════════════════════════════════════════════════════════
printf "\n${G}${BO}"
printf "╔══════════════════════════════════════════════════════╗\n"
if [ "$XORG_OK" = true ]; then
printf "║       SpectrOS instal·lat correctament! ✔            ║\n"
else
printf "║    SpectrOS instal·lat (Xorg necessita revisió) ⚠    ║\n"
fi
printf "╚══════════════════════════════════════════════════════╝\n"
printf "${NC}\n"

printf "  Usuari:       ${BO}$MAIN_USER${NC}  →  $MAIN_HOME\n"
printf "  Driver Xorg:  ${BO}$DRIVER_USED${NC}\n"
printf "  Apps:         ${BO}/usr/local/bin/spectros/${NC}\n\n"

if [ "$XORG_OK" = true ]; then
    printf "${G}Tot llest! Reinicieu per entrar a SpectrOS:${NC}\n"
    printf "  ${B}reboot${NC}\n\n"
    printf "En reiniciar veureu:\n"
    printf "  ${C}①${NC} Boot silenciós\n"
    printf "  ${C}②${NC} LightDM → Login (usuari: ${BO}$MAIN_USER${NC})\n"
    printf "  ${C}③${NC} XFCE amb les apps d'ArCom\n\n"
else
    printf "${Y}Xorg no ha passat el test. Comprova:${NC}\n"
    printf "  ${B}cat /tmp/xorg-test.log | grep '(EE)'${NC}\n\n"
    printf "I torna a executar:  ${B}sh install.sh${NC}\n\n"
fi
