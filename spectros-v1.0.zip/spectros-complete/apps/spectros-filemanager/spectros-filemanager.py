#!/usr/bin/env python3
# spectros-filemanager.py — SpectrOS File Manager
# ArCom Corporation — FreeBSD base — GTK3
# 3 panells: Sidebar / Llistat amb icones / Preview

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gtk, GdkPixbuf, GLib, Pango, Gdk
import os
import subprocess
import mimetypes
import stat
import datetime
import threading

# ── Icon mapping by extension ─────────────────────────────────────────────────
EXT_ICON = {
    # Documents
    "pdf":  "application-pdf",
    "doc":  "x-office-document", "docx": "x-office-document",
    "odt":  "x-office-document",
    "xls":  "x-office-spreadsheet", "xlsx": "x-office-spreadsheet",
    "ods":  "x-office-spreadsheet",
    "ppt":  "x-office-presentation", "pptx": "x-office-presentation",
    "txt":  "text-x-generic",
    "md":   "text-x-generic",
    # Images
    "png":  "image-x-generic", "jpg": "image-x-generic", "jpeg": "image-x-generic",
    "gif":  "image-x-generic", "bmp": "image-x-generic", "svg":  "image-x-generic",
    "webp": "image-x-generic",
    # Audio
    "mp3":  "audio-x-generic", "ogg": "audio-x-generic", "flac": "audio-x-generic",
    "wav":  "audio-x-generic", "m4a": "audio-x-generic",
    # Video
    "mp4":  "video-x-generic", "mkv": "video-x-generic", "avi":  "video-x-generic",
    "mov":  "video-x-generic", "webm": "video-x-generic",
    # Archives
    "zip":  "package-x-generic", "tar": "package-x-generic", "gz":  "package-x-generic",
    "bz2":  "package-x-generic", "xz":  "package-x-generic", "7z":  "package-x-generic",
    # Code
    "py":   "text-x-script", "sh":  "text-x-script", "rb":  "text-x-script",
    "js":   "text-x-script", "c":   "text-x-script", "cpp": "text-x-script",
    "h":    "text-x-script", "rs":  "text-x-script",
    # Binary
    "pkg":  "application-x-executable", "exe": "application-x-executable",
}

IMAGE_EXTS = {"png", "jpg", "jpeg", "gif", "bmp", "webp", "svg"}
TEXT_EXTS  = {"txt", "md", "py", "sh", "c", "cpp", "h", "rs", "js",
              "json", "xml", "html", "css", "conf", "cfg", "ini", "log"}


def human_size(n):
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def file_icon(path):
    if os.path.isdir(path):
        return "folder"
    ext = os.path.splitext(path)[1].lstrip(".").lower()
    return EXT_ICON.get(ext, "text-x-generic")


# ── File Manager Window ───────────────────────────────────────────────────────

class FileManagerWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="🗂️  SpectrOS FileManager")
        self.set_default_size(1280, 800)
        self.history = []
        self.future  = []
        self.current_path = os.path.expanduser("~")

        self._apply_css()
        self._build_ui()
        self.navigate(self.current_path, push=False)
        self.show_all()

    # ── CSS ───────────────────────────────────────────────────────────────────

    def _apply_css(self):
        css = b"""
        window { background-color: #1e2127; }

        .header-bar {
            background: linear-gradient(135deg, #1a3a5c 0%, #0d2137 100%);
            border-bottom: 2px solid #2e6da4;
            padding: 0 8px;
            min-height: 44px;
        }
        .nav-btn {
            background: transparent;
            color: #90caf9;
            border: none;
            border-radius: 4px;
            padding: 4px 8px;
            font-size: 16px;
            min-width: 32px;
        }
        .nav-btn:hover { background-color: #1e3a5f; }
        .nav-btn:disabled { color: #2e3a48; }

        .path-entry {
            background-color: #1a1e24;
            color: #e0e0e0;
            border: 1px solid #37474f;
            border-radius: 4px;
            padding: 4px 8px;
            font-family: monospace;
            font-size: 13px;
            min-width: 400px;
        }

        .sidebar {
            background-color: #1a1e24;
            border-right: 1px solid #2e3540;
        }
        .sidebar-section {
            font-size: 10px;
            font-weight: bold;
            color: #546e7a;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 8px 12px 2px 12px;
        }
        row.sidebar-row {
            padding: 4px 8px;
            border-radius: 0;
        }
        row.sidebar-row:selected {
            background-color: #1e3a5f;
        }
        row.sidebar-row:hover {
            background-color: #252932;
        }
        .sidebar-label {
            font-size: 13px;
            color: #b0bec5;
        }

        .file-list {
            background-color: #1e2127;
            color: #b0bec5;
        }
        .file-list row { padding: 2px 0; }
        .file-list row:selected { background-color: #1e3a5f; }
        .file-list row:hover { background-color: #252932; }

        .col-name  { font-size: 13px; color: #e0e0e0; }
        .col-size  { font-size: 11px; color: #78909c; }
        .col-date  { font-size: 11px; color: #546e7a; }
        .col-type  { font-size: 11px; color: #455a64; }

        .preview-panel {
            background-color: #1a1e24;
            border-left: 1px solid #2e3540;
        }
        .preview-title {
            font-size: 13px;
            font-weight: bold;
            color: #90caf9;
            padding: 10px 12px 4px 12px;
        }
        .preview-meta {
            font-size: 11px;
            color: #78909c;
            padding: 0 12px 4px 12px;
        }
        .preview-text {
            font-family: monospace;
            font-size: 11px;
            color: #78909c;
            background-color: #141720;
            padding: 8px;
        }

        .status-bar {
            background-color: #141720;
            border-top: 1px solid #2e3540;
            padding: 4px 12px;
        }
        .status-label { font-size: 11px; color: #546e7a; }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            self.get_screen(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    # ── UI Construction ───────────────────────────────────────────────────────

    def _build_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(root)

        # ── Toolbar ─────────────────────────────────────────────────────────
        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar.get_style_context().add_class("header-bar")

        self.back_btn  = Gtk.Button(label="◀")
        self.fwd_btn   = Gtk.Button(label="▶")
        self.up_btn    = Gtk.Button(label="▲")
        self.home_btn  = Gtk.Button(label="🏠")
        self.reload_btn = Gtk.Button(label="↻")

        for btn in [self.back_btn, self.fwd_btn, self.up_btn, self.home_btn, self.reload_btn]:
            btn.get_style_context().add_class("nav-btn")

        self.back_btn.connect("clicked", self._go_back)
        self.fwd_btn.connect("clicked", self._go_forward)
        self.up_btn.connect("clicked", self._go_up)
        self.home_btn.connect("clicked", lambda b: self.navigate(os.path.expanduser("~")))
        self.reload_btn.connect("clicked", lambda b: self.navigate(self.current_path, push=False))

        self.path_entry = Gtk.Entry()
        self.path_entry.get_style_context().add_class("path-entry")
        self.path_entry.connect("activate", self._path_entered)

        # Search
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Cercar...")
        self.search_entry.set_size_request(180, -1)
        self.search_entry.connect("search-changed", self._on_search)

        for w in [self.back_btn, self.fwd_btn, self.up_btn, self.home_btn,
                  self.reload_btn, self.path_entry]:
            toolbar.pack_start(w, False, False, 0)
        toolbar.pack_end(self.search_entry, False, False, 0)

        root.pack_start(toolbar, False, False, 0)

        # ── Main paned ──────────────────────────────────────────────────────
        main_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        main_paned.set_position(200)
        root.pack_start(main_paned, True, True, 0)

        # Sidebar
        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        sidebar_box.get_style_context().add_class("sidebar")
        sidebar_box.set_size_request(200, -1)

        self.sidebar_list = Gtk.ListBox()
        self.sidebar_list.get_style_context().add_class("sidebar")
        self.sidebar_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.sidebar_list.connect("row-activated", self._sidebar_activated)

        self._build_sidebar()

        sidebar_scroll = Gtk.ScrolledWindow()
        sidebar_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sidebar_scroll.add(self.sidebar_list)
        sidebar_box.pack_start(sidebar_scroll, True, True, 0)

        # Center list + preview
        center_paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        center_paned.set_position(700)

        # File list (TreeView)
        list_scroll = Gtk.ScrolledWindow()
        list_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)

        # Columns: icon, name, size, date, type
        self.store = Gtk.ListStore(
            GdkPixbuf.Pixbuf,  # 0 icon
            str,               # 1 name
            str,               # 2 size display
            str,               # 3 date display
            str,               # 4 type
            str,               # 5 full path (hidden)
            int,               # 6 raw size (for sort)
            int,               # 7 is_dir (for sort)
        )
        self.filter_store = self.store.filter_new()
        self.filter_store.set_visible_func(self._filter_func)

        self.tree = Gtk.TreeView(model=self.filter_store)
        self.tree.get_style_context().add_class("file-list")
        self.tree.set_headers_visible(True)
        self.tree.set_activate_on_single_click(False)
        self.tree.connect("row-activated", self._row_activated)
        self.tree.connect("cursor-changed", self._row_selected)

        # Enable sorting
        sortable = Gtk.TreeModelSort(model=self.filter_store)
        self.tree.set_model(sortable)

        icon_r = Gtk.CellRendererPixbuf()
        name_r = Gtk.CellRendererText()
        name_r.set_property("ellipsize", Pango.EllipsizeMode.MIDDLE)
        size_r = Gtk.CellRendererText()
        date_r = Gtk.CellRendererText()
        type_r = Gtk.CellRendererText()

        col_name = Gtk.TreeViewColumn("Nom")
        col_name.pack_start(icon_r, False)
        col_name.pack_start(name_r, True)
        col_name.add_attribute(icon_r, "pixbuf", 0)
        col_name.add_attribute(name_r, "text", 1)
        col_name.set_sort_column_id(1)
        col_name.set_min_width(280)
        col_name.set_expand(True)

        col_size = Gtk.TreeViewColumn("Mida", size_r, text=2)
        col_size.set_sort_column_id(6)
        col_size.set_min_width(80)

        col_date = Gtk.TreeViewColumn("Modificat", date_r, text=3)
        col_date.set_sort_column_id(3)
        col_date.set_min_width(130)

        col_type = Gtk.TreeViewColumn("Tipus", type_r, text=4)
        col_type.set_min_width(100)

        for col in [col_name, col_size, col_date, col_type]:
            self.tree.append_column(col)

        # Default sort: dirs first, then name
        self.store.set_sort_column_id(7, Gtk.SortType.DESCENDING)

        list_scroll.add(self.tree)
        center_paned.pack1(list_scroll, True, True)

        # Preview panel
        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        preview_box.get_style_context().add_class("preview-panel")
        preview_box.set_size_request(280, -1)

        self.preview_name = Gtk.Label(label="")
        self.preview_name.get_style_context().add_class("preview-title")
        self.preview_name.set_halign(Gtk.Align.START)
        self.preview_name.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        preview_box.pack_start(self.preview_name, False, False, 0)

        self.preview_meta = Gtk.Label(label="")
        self.preview_meta.get_style_context().add_class("preview-meta")
        self.preview_meta.set_halign(Gtk.Align.START)
        self.preview_meta.set_line_wrap(True)
        preview_box.pack_start(self.preview_meta, False, False, 0)

        self.preview_img = Gtk.Image()
        self.preview_img.set_margin_top(8)
        preview_box.pack_start(self.preview_img, False, False, 0)

        preview_text_scroll = Gtk.ScrolledWindow()
        preview_text_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.preview_buf = Gtk.TextBuffer()
        self.preview_tv = Gtk.TextView(buffer=self.preview_buf)
        self.preview_tv.set_editable(False)
        self.preview_tv.set_cursor_visible(False)
        self.preview_tv.set_wrap_mode(Gtk.WrapMode.WORD)
        self.preview_tv.get_style_context().add_class("preview-text")
        preview_text_scroll.add(self.preview_tv)
        preview_box.pack_start(preview_text_scroll, True, True, 0)

        center_paned.pack2(preview_box, False, False)

        main_paned.pack1(sidebar_box, False, False)
        main_paned.pack2(center_paned, True, True)

        # ── Status bar ──────────────────────────────────────────────────────
        self.status_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.status_bar.get_style_context().add_class("status-bar")
        self.status_lbl = Gtk.Label(label="")
        self.status_lbl.get_style_context().add_class("status-label")
        self.status_lbl.set_halign(Gtk.Align.START)
        self.status_bar.pack_start(self.status_lbl, True, True, 0)
        root.pack_start(self.status_bar, False, False, 0)

        # Context menu
        self._build_context_menu()

        # Right-click
        self.tree.connect("button-press-event", self._on_button_press)

    def _build_sidebar(self):
        locations = [
            ("LLOCS", None),
            ("🏠  Inici", os.path.expanduser("~")),
            ("🖥️  Escriptori", os.path.expanduser("~/Desktop")),
            ("📄  Documents", os.path.expanduser("~/Documents")),
            ("📥  Descàrregues", os.path.expanduser("~/Downloads")),
            ("🖼️  Imatges", os.path.expanduser("~/Pictures")),
            ("🎵  Música", os.path.expanduser("~/Music")),
            ("🎥  Vídeos", os.path.expanduser("~/Videos")),
            ("SISTEMA", None),
            ("💻  Arrel (/)", "/"),
            ("🔧  /usr/local", "/usr/local"),
            ("📦  /var", "/var"),
            ("⚙️  SpectrOS", "/usr/local/bin/spectros"),
        ]
        for name, path in locations:
            if path is None:
                lbl = Gtk.Label(label=name)
                lbl.get_style_context().add_class("sidebar-section")
                lbl.set_halign(Gtk.Align.START)
                row = Gtk.ListBoxRow()
                row.set_selectable(False)
                row.set_activatable(False)
                row.add(lbl)
            else:
                lbl = Gtk.Label(label=name)
                lbl.get_style_context().add_class("sidebar-label")
                lbl.set_halign(Gtk.Align.START)
                lbl.set_margin_start(8)
                row = Gtk.ListBoxRow()
                row.get_style_context().add_class("sidebar-row")
                row.nav_path = path
                row.add(lbl)
            self.sidebar_list.add(row)

    def _build_context_menu(self):
        self.ctx_menu = Gtk.Menu()
        items = [
            ("📂  Obrir",          self._ctx_open),
            ("🔍  Obrir amb...",   self._ctx_open_with),
            (None, None),
            ("📋  Copiar ruta",    self._ctx_copy_path),
            ("ℹ️  Propietats",     self._ctx_properties),
            (None, None),
            ("🗑️  Suprimir",      self._ctx_delete),
        ]
        for label, cb in items:
            if label is None:
                self.ctx_menu.append(Gtk.SeparatorMenuItem())
            else:
                mi = Gtk.MenuItem(label=label)
                if cb:
                    mi.connect("activate", cb)
                self.ctx_menu.append(mi)
        self.ctx_menu.show_all()

    # ── Navigation ────────────────────────────────────────────────────────────

    def navigate(self, path, push=True):
        path = os.path.realpath(os.path.expanduser(path))
        if not os.path.isdir(path):
            return
        if push and self.current_path != path:
            self.history.append(self.current_path)
            self.future.clear()
        self.current_path = path
        self.path_entry.set_text(path)
        self._update_nav_buttons()
        self._load_directory(path)

    def _update_nav_buttons(self):
        self.back_btn.set_sensitive(bool(self.history))
        self.fwd_btn.set_sensitive(bool(self.future))
        self.up_btn.set_sensitive(self.current_path != "/")

    def _go_back(self, btn):
        if self.history:
            self.future.append(self.current_path)
            self.navigate(self.history.pop(), push=False)

    def _go_forward(self, btn):
        if self.future:
            self.history.append(self.current_path)
            self.navigate(self.future.pop(), push=False)

    def _go_up(self, btn):
        parent = os.path.dirname(self.current_path)
        if parent != self.current_path:
            self.navigate(parent)

    def _path_entered(self, entry):
        self.navigate(entry.get_text())

    def _sidebar_activated(self, lb, row):
        if hasattr(row, "nav_path"):
            self.navigate(row.nav_path)

    # ── Directory Loading ─────────────────────────────────────────────────────

    def _load_directory(self, path):
        self.store.clear()
        self.preview_name.set_text("")
        self.preview_meta.set_text("")
        self.preview_img.clear()
        self.preview_buf.set_text("")

        theme = Gtk.IconTheme.get_default()
        count = 0
        errors = 0

        try:
            entries = sorted(os.listdir(path))
        except PermissionError:
            self.status_lbl.set_text(f"⚠  Sense permís per llegir: {path}")
            return

        # Dirs first, then files
        dirs  = [e for e in entries if os.path.isdir(os.path.join(path, e))]
        files = [e for e in entries if not os.path.isdir(os.path.join(path, e))]

        for name in dirs + files:
            full = os.path.join(path, name)
            try:
                st = os.stat(full)
                size_bytes = st.st_size
                mtime = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M")
                is_dir = os.path.isdir(full)
                size_str = "—" if is_dir else human_size(size_bytes)
                type_str = "Carpeta" if is_dir else self._get_type(name)

                icon_name = file_icon(full)
                try:
                    pixbuf = theme.load_icon(icon_name, 20, Gtk.IconLookupFlags.FORCE_SIZE)
                except Exception:
                    pixbuf = theme.load_icon("text-x-generic", 20, Gtk.IconLookupFlags.FORCE_SIZE)

                self.store.append([
                    pixbuf, name, size_str, mtime, type_str,
                    full, size_bytes, 1 if is_dir else 0
                ])
                count += 1
            except Exception:
                errors += 1

        total = len(dirs) + len(files)
        status = f"{count} elements  ({len(dirs)} carpetes, {len(files)} fitxers)"
        if errors:
            status += f"  ⚠ {errors} inaccessibles"
        self.status_lbl.set_text(status)

    def _get_type(self, name):
        ext = os.path.splitext(name)[1].lstrip(".").lower()
        mime, _ = mimetypes.guess_type(name)
        if mime:
            return mime.split("/")[-1].upper()
        return ext.upper() if ext else "Fitxer"

    # ── Filtering ─────────────────────────────────────────────────────────────

    def _filter_func(self, model, it, data):
        query = self.search_entry.get_text().lower().strip()
        if not query:
            return True
        name = model.get_value(it, 1) or ""
        return query in name.lower()

    def _on_search(self, entry):
        self.filter_store.refilter()

    # ── Selection & Preview ───────────────────────────────────────────────────

    def _row_selected(self, tree):
        model, it = tree.get_selection().get_selected()
        if not it:
            return
        path = model.get_value(it, 5)
        name = model.get_value(it, 1)
        if not path:
            return
        self._show_preview(path, name)

    def _show_preview(self, path, name):
        self.preview_name.set_text(name)
        self.preview_img.clear()
        self.preview_buf.set_text("")

        try:
            st = os.stat(path)
            size = human_size(st.st_size)
            mtime = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%d/%m/%Y %H:%M")
            perms = oct(stat.S_IMODE(st.st_mode))
            meta = f"Mida: {size}  ·  Modificat: {mtime}  ·  Permisos: {perms}"
            self.preview_meta.set_text(meta)
        except Exception:
            self.preview_meta.set_text("")

        ext = os.path.splitext(name)[1].lstrip(".").lower()

        if ext in IMAGE_EXTS:
            threading.Thread(target=self._load_image_preview, args=(path,), daemon=True).start()
        elif ext in TEXT_EXTS:
            threading.Thread(target=self._load_text_preview, args=(path,), daemon=True).start()
        else:
            self.preview_buf.set_text(f"({self._get_type(name)})\n\nNo hi ha previsualització disponible.")

    def _load_image_preview(self, path):
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 260, 260, True)
            GLib.idle_add(self.preview_img.set_from_pixbuf, pixbuf)
        except Exception as e:
            GLib.idle_add(self.preview_buf.set_text, f"Error carregant imatge:\n{e}")

    def _load_text_preview(self, path):
        try:
            with open(path, "r", errors="replace") as f:
                content = f.read(3000)
            GLib.idle_add(self.preview_buf.set_text, content)
        except Exception as e:
            GLib.idle_add(self.preview_buf.set_text, f"Error llegint fitxer:\n{e}")

    # ── Activation ────────────────────────────────────────────────────────────

    def _row_activated(self, tree, tree_path, column):
        model = tree.get_model()
        it = model.get_iter(tree_path)
        full = model.get_value(it, 5)
        if os.path.isdir(full):
            self.navigate(full)
        else:
            subprocess.Popen(["xdg-open", full])

    # ── Context Menu ──────────────────────────────────────────────────────────

    def _on_button_press(self, widget, event):
        if event.button == 3:
            self.ctx_menu.popup_at_pointer(event)
            return True

    def _selected_path(self):
        model, it = self.tree.get_selection().get_selected()
        if it:
            return model.get_value(it, 5)
        return None

    def _ctx_open(self, mi):
        path = self._selected_path()
        if path:
            if os.path.isdir(path):
                self.navigate(path)
            else:
                subprocess.Popen(["xdg-open", path])

    def _ctx_open_with(self, mi):
        path = self._selected_path()
        if path:
            dlg = Gtk.AppChooserDialog(parent=self, flags=0, gfile=None)
            if dlg.run() == Gtk.ResponseType.OK:
                app_info = dlg.get_app_info()
                if app_info:
                    app_info.launch_uris([f"file://{path}"], None)
            dlg.destroy()

    def _ctx_copy_path(self, mi):
        path = self._selected_path()
        if path:
            cb = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
            cb.set_text(path, -1)

    def _ctx_properties(self, mi):
        path = self._selected_path()
        if not path:
            return
        try:
            st = os.stat(path)
            msg = (
                f"Nom: {os.path.basename(path)}\n"
                f"Ruta: {path}\n"
                f"Mida: {human_size(st.st_size)}\n"
                f"Modificat: {datetime.datetime.fromtimestamp(st.st_mtime)}\n"
                f"Permisos: {oct(stat.S_IMODE(st.st_mode))}\n"
                f"Propietari UID: {st.st_uid}\n"
                f"Grup GID: {st.st_gid}\n"
            )
        except Exception as e:
            msg = str(e)
        dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                message_type=Gtk.MessageType.INFO,
                                buttons=Gtk.ButtonsType.OK, text="Propietats")
        dlg.format_secondary_text(msg)
        dlg.run(); dlg.destroy()

    def _ctx_delete(self, mi):
        path = self._selected_path()
        if not path:
            return
        dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                message_type=Gtk.MessageType.WARNING,
                                buttons=Gtk.ButtonsType.YES_NO,
                                text=f"Suprimir '{os.path.basename(path)}'?")
        dlg.format_secondary_text("Aquesta acció no es pot desfer.")
        if dlg.run() == Gtk.ResponseType.YES:
            try:
                if os.path.isdir(path):
                    import shutil; shutil.rmtree(path)
                else:
                    os.remove(path)
                self.navigate(self.current_path, push=False)
            except Exception as e:
                err = Gtk.MessageDialog(transient_for=self, modal=True,
                                        message_type=Gtk.MessageType.ERROR,
                                        buttons=Gtk.ButtonsType.OK, text=str(e))
                err.run(); err.destroy()
        dlg.destroy()


# ── Application ───────────────────────────────────────────────────────────────

class FileManagerApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.arcom.spectros.filemanager")

    def do_activate(self):
        FileManagerWindow(self).show()


if __name__ == "__main__":
    FileManagerApp().run()
