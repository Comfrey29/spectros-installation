#!/usr/bin/env python3
# spectros-shop.py — SpectrOS Software Shop
# ArCom Corporation — FreeBSD base — GTK3
# Seccions: ArCom Apps / FreeBSD OSS / Eines / Jocs

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Pango
import subprocess
import threading
import webbrowser

# ── Catalog ───────────────────────────────────────────────────────────────────

CATALOG = {
    "ArCom Apps": [
        {
            "name": "SpectrOS Config",
            "version": "1.0.0",
            "category": "Sistema",
            "price": "Gratis",
            "icon": "⚙️",
            "desc": (
                "Panell de configuració complet de SpectrOS. Gestiona xarxes WiFi, "
                "Bluetooth, usuaris del sistema, serveis de FreeBSD i actualitzacions "
                "des d'una sola interfície."
            ),
            "installed": True,
            "pkg": None,
            "url": "https://github.com/Comfrey29/spectros-updater",
        },
        {
            "name": "SpectrOS FileManager",
            "version": "1.0.0",
            "category": "Sistema",
            "price": "Gratis",
            "icon": "🗂️",
            "desc": (
                "Gestor de fitxers de 3 panells per a SpectrOS. Sidebar de llocs, "
                "llistat amb icones per tipus, previsualització d'imatges i text, "
                "menú contextual i barra de cerca integrada."
            ),
            "installed": True,
            "pkg": None,
            "url": "https://github.com/Comfrey29/spectros-updater",
        },
        {
            "name": "SpectrOS Updater",
            "version": "1.0.0",
            "category": "Sistema",
            "price": "Gratis",
            "icon": "🔄",
            "desc": (
                "Eina d'actualització de SpectrOS. Comprova noves versions al repositori "
                "GitHub d'ArCom Corporation, gestiona pkg upgrade i freebsd-update "
                "amb una interfície visual neta."
            ),
            "installed": True,
            "pkg": None,
            "url": "https://github.com/Comfrey29/spectros-updater",
        },
        {
            "name": "ArCom Terminal",
            "version": "0.9.1",
            "category": "Sistema",
            "price": "Gratis",
            "icon": "🖥️",
            "desc": (
                "Emulador de terminal lleuger dissenyat per a SpectrOS. Suport de pestanyes, "
                "perfils de color, integració amb zsh/tcsh i còpia/enganxa avançada."
            ),
            "installed": False,
            "pkg": "xterm",
            "url": None,
        },
        {
            "name": "ArCom TextEditor",
            "version": "1.2.0",
            "category": "Productivitat",
            "price": "Gratis",
            "icon": "📝",
            "desc": (
                "Editor de text senzill i ràpid per a SpectrOS. Ressaltat de sintaxi "
                "per a Python, Shell, C, HTML, Markdown i JSON. Mode nocturn integrat."
            ),
            "installed": False,
            "pkg": "mousepad",
            "url": None,
        },
        {
            "name": "ArCom ImageViewer",
            "version": "1.0.3",
            "category": "Multimèdia",
            "price": "Gratis",
            "icon": "🖼️",
            "desc": (
                "Visor d'imatges lleuger per a SpectrOS. Suport PNG, JPG, GIF, WEBP, SVG, BMP. "
                "Rotació, zoom, mode pantalla completa i presentació de diapositives."
            ),
            "installed": False,
            "pkg": "ristretto",
            "url": None,
        },
        {
            "name": "ArCom PDFReader",
            "version": "2.0.0",
            "category": "Productivitat",
            "price": "Gratis",
            "icon": "📕",
            "desc": (
                "Lector de PDF optimitzat per a SpectrOS. Navegació per pàgines, "
                "cerca de text, marcadors i exportació a text pla. Baix consum de RAM."
            ),
            "installed": False,
            "pkg": "evince",
            "url": None,
        },
        {
            "name": "ArCom SystemMonitor",
            "version": "1.1.0",
            "category": "Sistema",
            "price": "Gratis",
            "icon": "📊",
            "desc": (
                "Monitor de sistema en temps real per a FreeBSD. CPU, RAM, swap, "
                "processos, interfícies de xarxa i temperatura dels nuclis. "
                "Gràfiques en temps real."
            ),
            "installed": False,
            "pkg": "gnome-system-monitor",
            "url": None,
        },
        {
            "name": "ArCom Backup",
            "version": "0.8.0",
            "category": "Sistema",
            "price": "4,99 €",
            "icon": "💾",
            "desc": (
                "Eina de còpies de seguretat per a SpectrOS. Backup incremental, "
                "programació automàtica, xifrat AES-256 i restauració selectiva de fitxers."
            ),
            "installed": False,
            "pkg": None,
            "url": None,
        },
        {
            "name": "ArCom VPN Client",
            "version": "1.0.0",
            "category": "Xarxa",
            "price": "9,99 €/any",
            "icon": "🔐",
            "desc": (
                "Client VPN d'ArCom Corporation per a SpectrOS. Suport OpenVPN i WireGuard, "
                "connexió automàtica, kill switch i DNS privat d'ArCom."
            ),
            "installed": False,
            "pkg": None,
            "url": None,
        },
    ],
    "FreeBSD / Codi Obert": [
        {
            "name": "Firefox",
            "version": "latest",
            "category": "Internet",
            "price": "Gratis",
            "icon": "🦊",
            "desc": (
                "Navegador web lliure i de codi obert de Mozilla Foundation. "
                "Respecta la privacitat, actualitzacions freqüents i gran ecosistema d'extensions."
            ),
            "installed": False,
            "pkg": "firefox",
            "url": "https://www.mozilla.org/firefox/",
        },
        {
            "name": "LibreOffice",
            "version": "latest",
            "category": "Oficina",
            "price": "Gratis",
            "icon": "📋",
            "desc": (
                "Suite ofimàtica completa de codi obert. Processador de textos, "
                "full de càlcul, presentacions, base de dades i editor de fórmules. "
                "Compatible amb formats Microsoft Office."
            ),
            "installed": False,
            "pkg": "libreoffice",
            "url": "https://www.libreoffice.org/",
        },
        {
            "name": "VLC",
            "version": "latest",
            "category": "Multimèdia",
            "price": "Gratis",
            "icon": "🎬",
            "desc": (
                "Reproductor multimèdia universal. Suporta pràcticament tots els "
                "formats d'àudio i vídeo sense còdecs addicionals. Streaming, "
                "subtítols i conversió de formats."
            ),
            "installed": False,
            "pkg": "vlc",
            "url": "https://www.videolan.org/vlc/",
        },
        {
            "name": "GIMP",
            "version": "latest",
            "category": "Gràfics",
            "price": "Gratis",
            "icon": "🎨",
            "desc": (
                "Editor d'imatges professional de codi obert. Alternativa a Photoshop "
                "amb suport de capes, filtres avançats, scripts i exportació a múltiples "
                "formats. Ideal per a SpectrOS."
            ),
            "installed": False,
            "pkg": "gimp",
            "url": "https://www.gimp.org/",
        },
        {
            "name": "Inkscape",
            "version": "latest",
            "category": "Gràfics",
            "price": "Gratis",
            "icon": "✏️",
            "desc": (
                "Editor de gràfics vectorials SVG professional. Creació d'il·lustracions, "
                "logotips, icones i dissenys per a impressió o web. Totalment gratuït i de codi obert."
            ),
            "installed": False,
            "pkg": "inkscape",
            "url": "https://inkscape.org/",
        },
        {
            "name": "Thunderbird",
            "version": "latest",
            "category": "Internet",
            "price": "Gratis",
            "icon": "📧",
            "desc": (
                "Client de correu electrònic de Mozilla. Gestió de múltiples comptes, "
                "filtre de correu brossa, xifrat GPG, calendari integrat i RSS."
            ),
            "installed": False,
            "pkg": "thunderbird",
            "url": "https://www.thunderbird.net/",
        },
        {
            "name": "Vim",
            "version": "latest",
            "category": "Desenvolupament",
            "price": "Gratis",
            "icon": "⌨️",
            "desc": (
                "Editor de text modal llegendari. Extremadament lleuger i potent, "
                "amb ressaltat de sintaxi per a centenars de llenguatges, macros "
                "i un ecosistema de plugins immens."
            ),
            "installed": False,
            "pkg": "vim",
            "url": "https://www.vim.org/",
        },
        {
            "name": "Git",
            "version": "latest",
            "category": "Desenvolupament",
            "price": "Gratis",
            "icon": "🔀",
            "desc": (
                "Sistema de control de versions distribuït. Estàndard de la indústria "
                "per a gestió de codi font. Integrat amb GitHub, GitLab, Gitea i més."
            ),
            "installed": False,
            "pkg": "git",
            "url": "https://git-scm.com/",
        },
        {
            "name": "Audacity",
            "version": "latest",
            "category": "Multimèdia",
            "price": "Gratis",
            "icon": "🎙️",
            "desc": (
                "Editor d'àudio multipista de codi obert. Gravació, edició, efectes, "
                "exportació a MP3/OGG/FLAC i eliminació de soroll. Perfecte per a podcasts."
            ),
            "installed": False,
            "pkg": "audacity",
            "url": "https://www.audacityteam.org/",
        },
        {
            "name": "Transmission",
            "version": "latest",
            "category": "Internet",
            "price": "Gratis",
            "icon": "🌊",
            "desc": (
                "Client BitTorrent lleuger i senzill. Interfície GTK neta, "
                "baix consum de recursos, programació de velocitat i descàrrega magnetica."
            ),
            "installed": False,
            "pkg": "transmission-gtk",
            "url": "https://transmissionbt.com/",
        },
        {
            "name": "Calibre",
            "version": "latest",
            "category": "Productivitat",
            "price": "Gratis",
            "icon": "📚",
            "desc": (
                "Gestor d'e-books complet. Organitza, converteix i llegeix e-books "
                "en EPUB, MOBI, PDF i més. Sincronització amb lectors electrònics."
            ),
            "installed": False,
            "pkg": "calibre",
            "url": "https://calibre-ebook.com/",
        },
        {
            "name": "KeePassXC",
            "version": "latest",
            "category": "Seguretat",
            "price": "Gratis",
            "icon": "🔑",
            "desc": (
                "Gestor de contrasenyes de codi obert. Base de dades xifrada AES-256, "
                "generador de contrasenyes, integració TOTP i integració amb navegadors."
            ),
            "installed": False,
            "pkg": "keepassxc",
            "url": "https://keepassxc.org/",
        },
    ],
}

CATEGORIES = ["Totes", "Sistema", "Productivitat", "Internet", "Multimèdia",
               "Gràfics", "Desenvolupament", "Xarxa", "Seguretat", "Oficina"]


# ── App Card Widget ───────────────────────────────────────────────────────────

class AppCard(Gtk.ListBoxRow):
    def __init__(self, app_data):
        super().__init__()
        self.app_data = app_data
        self.get_style_context().add_class("app-card")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_start(12)
        box.set_margin_end(12)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        # Icon
        icon_lbl = Gtk.Label(label=app_data["icon"])
        icon_lbl.get_style_context().add_class("app-icon")
        icon_lbl.set_size_request(48, 48)

        # Info
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)

        name_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        name_lbl = Gtk.Label(label=app_data["name"])
        name_lbl.get_style_context().add_class("app-name")
        name_lbl.set_halign(Gtk.Align.START)

        cat_lbl = Gtk.Label(label=app_data["category"])
        cat_lbl.get_style_context().add_class("app-cat")

        if app_data["installed"]:
            inst_lbl = Gtk.Label(label="✔ Instal·lat")
            inst_lbl.get_style_context().add_class("installed-badge")
            name_row.pack_end(inst_lbl, False, False, 0)

        name_row.pack_start(name_lbl, False, False, 0)
        name_row.pack_start(cat_lbl, False, False, 0)

        desc_lbl = Gtk.Label(label=app_data["desc"])
        desc_lbl.get_style_context().add_class("app-desc")
        desc_lbl.set_halign(Gtk.Align.START)
        desc_lbl.set_line_wrap(True)
        desc_lbl.set_max_width_chars(70)

        ver_lbl = Gtk.Label(label=f"v{app_data['version']}")
        ver_lbl.get_style_context().add_class("app-ver")
        ver_lbl.set_halign(Gtk.Align.START)

        info_box.pack_start(name_row, False, False, 0)
        info_box.pack_start(desc_lbl, False, False, 0)
        info_box.pack_start(ver_lbl, False, False, 0)

        # Right side: price + button
        right_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        right_box.set_halign(Gtk.Align.END)
        right_box.set_valign(Gtk.Align.CENTER)

        price_lbl = Gtk.Label(label=app_data["price"])
        price_lbl.get_style_context().add_class(
            "price-free" if app_data["price"] == "Gratis" else "price-paid"
        )

        if app_data["installed"]:
            self.install_btn = Gtk.Button(label="Obert")
            self.install_btn.get_style_context().add_class("btn-open")
        else:
            self.install_btn = Gtk.Button(
                label="Instal·lar" if app_data["pkg"] else "Comprar"
            )
            self.install_btn.get_style_context().add_class(
                "btn-install" if app_data["pkg"] else "btn-buy"
            )
        self.install_btn.connect("clicked", self._on_action)

        right_box.pack_start(price_lbl, False, False, 0)
        right_box.pack_start(self.install_btn, False, False, 0)

        box.pack_start(icon_lbl, False, False, 0)
        box.pack_start(info_box, True, True, 0)
        box.pack_end(right_box, False, False, 0)

        self.add(box)

    def _on_action(self, btn):
        app = self.app_data
        if app["installed"]:
            return
        if app["pkg"]:
            self._install_pkg(app["pkg"])
        elif app["url"]:
            webbrowser.open(app["url"])
        else:
            dlg = Gtk.MessageDialog(
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=f"Comprar {app['name']}"
            )
            dlg.format_secondary_text(
                f"Preu: {app['price']}\n\n"
                "Per comprar aquesta aplicació visiteu:\nhttps://arcom.cat/shop"
            )
            dlg.run(); dlg.destroy()

    def _install_pkg(self, pkg):
        dlg = Gtk.MessageDialog(
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Instal·lar {self.app_data['name']}?"
        )
        dlg.format_secondary_text(
            f"S'executarà: pkg install -y {pkg}\n"
            "Requereix connexió a internet i privilegis de root."
        )
        resp = dlg.run(); dlg.destroy()
        if resp == Gtk.ResponseType.YES:
            self.install_btn.set_sensitive(False)
            self.install_btn.set_label("Instal·lant...")
            threading.Thread(
                target=self._do_install, args=(pkg,), daemon=True
            ).start()

    def _do_install(self, pkg):
        try:
            result = subprocess.run(
                ["pkexec", "pkg", "install", "-y", pkg],
                capture_output=True, text=True, timeout=300
            )
            if result.returncode == 0:
                GLib.idle_add(self._install_success)
            else:
                GLib.idle_add(self._install_error, result.stderr[-400:])
        except Exception as e:
            GLib.idle_add(self._install_error, str(e))

    def _install_success(self):
        self.install_btn.set_label("✔ Instal·lat")
        self.install_btn.get_style_context().remove_class("btn-install")
        self.install_btn.get_style_context().add_class("btn-open")
        self.app_data["installed"] = True

    def _install_error(self, err):
        self.install_btn.set_sensitive(True)
        self.install_btn.set_label("Instal·lar")
        dlg = Gtk.MessageDialog(
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text="Error d'instal·lació"
        )
        dlg.format_secondary_text(err)
        dlg.run(); dlg.destroy()


# ── Shop Window ───────────────────────────────────────────────────────────────

class ShopWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="🛒  SpectrOS Shop")
        self.set_default_size(980, 720)
        self._active_section = "ArCom Apps"
        self._active_category = "Totes"
        self._search_query = ""

        self._apply_css()
        self._build_ui()
        self._populate()
        self.show_all()

    # ── CSS ───────────────────────────────────────────────────────────────────

    def _apply_css(self):
        css = b"""
        window { background-color: #1e2127; }

        /* Header */
        .shop-header {
            background: linear-gradient(135deg, #0d2137 0%, #1a3a5c 60%, #0a3d2b 100%);
            padding: 16px 24px;
            border-bottom: 2px solid #2e6da4;
        }
        .shop-title {
            font-size: 22px;
            font-weight: bold;
            color: #e8eaf6;
            letter-spacing: 1px;
        }
        .shop-subtitle {
            font-size: 11px;
            color: #7a9cbf;
        }

        /* Section tabs */
        .section-tab {
            background: transparent;
            color: #7a8a9a;
            border: none;
            border-bottom: 3px solid transparent;
            border-radius: 0;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: bold;
        }
        .section-tab:hover { color: #90caf9; }
        .section-tab-active {
            color: #90caf9;
            border-bottom: 3px solid #2e6da4;
        }

        /* Filter bar */
        .filter-bar {
            background-color: #1a1e24;
            border-bottom: 1px solid #2e3540;
            padding: 8px 16px;
        }
        .cat-btn {
            background: transparent;
            color: #546e7a;
            border: 1px solid #2e3540;
            border-radius: 12px;
            padding: 3px 12px;
            font-size: 11px;
            margin-right: 4px;
        }
        .cat-btn:hover { background-color: #252932; color: #90caf9; }
        .cat-btn-active {
            background-color: #1e3a5f;
            color: #90caf9;
            border-color: #2e6da4;
        }

        /* Search */
        .search-entry {
            background-color: #252932;
            color: #e0e0e0;
            border: 1px solid #37474f;
            border-radius: 6px;
            padding: 6px 12px;
            font-size: 13px;
            min-width: 220px;
        }

        /* App cards */
        .app-card {
            background-color: #252932;
            border: 1px solid #2e3540;
            border-radius: 8px;
            margin: 4px 12px;
        }
        .app-card:hover { border-color: #2e6da4; background-color: #2a3240; }
        .app-card:selected { background-color: #1e3a5f; }

        .app-icon { font-size: 30px; }
        .app-name {
            font-size: 14px;
            font-weight: bold;
            color: #e0e0e0;
        }
        .app-cat {
            font-size: 10px;
            color: #546e7a;
            background-color: #1a1e24;
            border-radius: 8px;
            padding: 1px 8px;
            margin-top: 2px;
        }
        .app-desc {
            font-size: 12px;
            color: #78909c;
            margin-top: 2px;
        }
        .app-ver { font-size: 10px; color: #37474f; }

        .installed-badge {
            font-size: 10px;
            color: #81c784;
            background-color: #1b2e1e;
            border-radius: 8px;
            padding: 1px 8px;
        }

        .price-free {
            font-size: 13px;
            font-weight: bold;
            color: #81c784;
        }
        .price-paid {
            font-size: 13px;
            font-weight: bold;
            color: #ffb74d;
        }

        .btn-install {
            background: linear-gradient(135deg, #1565c0, #0d47a1);
            color: #e3f2fd;
            border: none;
            border-radius: 6px;
            padding: 6px 16px;
            font-weight: bold;
            font-size: 12px;
            min-width: 100px;
        }
        .btn-install:hover { background: linear-gradient(135deg, #1976d2, #1565c0); }

        .btn-buy {
            background: linear-gradient(135deg, #e65100, #bf360c);
            color: #fff3e0;
            border: none;
            border-radius: 6px;
            padding: 6px 16px;
            font-weight: bold;
            font-size: 12px;
            min-width: 100px;
        }

        .btn-open {
            background-color: #2a3240;
            color: #90caf9;
            border: 1px solid #37474f;
            border-radius: 6px;
            padding: 6px 16px;
            font-size: 12px;
            min-width: 100px;
        }

        /* Status bar */
        .shop-status {
            background-color: #141720;
            border-top: 1px solid #2e3540;
            padding: 6px 16px;
        }
        .shop-status-lbl { font-size: 11px; color: #546e7a; }

        /* Donation strip */
        .donation-strip {
            background: linear-gradient(90deg, #0d2137, #1a3a5c);
            border-top: 1px solid #2e6da4;
            padding: 10px 20px;
        }
        .donation-lbl {
            font-size: 12px;
            color: #7a9cbf;
        }
        .donation-btn {
            background: linear-gradient(135deg, #1b5e20, #2e7d32);
            color: #c8e6c9;
            border: none;
            border-radius: 6px;
            padding: 6px 14px;
            font-size: 12px;
        }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            self.get_screen(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(root)

        # ── Header ──────────────────────────────────────────────────────────
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        header.get_style_context().add_class("shop-header")

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        t = Gtk.Label(label="🛒  SpectrOS Software Shop")
        t.get_style_context().add_class("shop-title")
        t.set_halign(Gtk.Align.START)
        s = Gtk.Label(label="ArCom Corporation · FreeBSD / Codi Obert")
        s.get_style_context().add_class("shop-subtitle")
        s.set_halign(Gtk.Align.START)
        title_box.pack_start(t, False, False, 0)
        title_box.pack_start(s, False, False, 0)

        self.search_entry = Gtk.SearchEntry()
        self.search_entry.get_style_context().add_class("search-entry")
        self.search_entry.set_placeholder_text("Cercar aplicació...")
        self.search_entry.connect("search-changed", self._on_search)

        header.pack_start(title_box, True, True, 0)
        header.pack_end(self.search_entry, False, False, 0)
        root.pack_start(header, False, False, 0)

        # ── Section tabs ─────────────────────────────────────────────────────
        tab_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        tab_box.get_style_context().add_class("filter-bar")
        self.section_btns = {}
        for section in CATALOG.keys():
            btn = Gtk.Button(label=section)
            btn.get_style_context().add_class("section-tab")
            btn.section = section
            btn.connect("clicked", self._on_section)
            if section == self._active_section:
                btn.get_style_context().add_class("section-tab-active")
            tab_box.pack_start(btn, False, False, 0)
            self.section_btns[section] = btn
        root.pack_start(tab_box, False, False, 0)

        # ── Category filter ──────────────────────────────────────────────────
        self.cat_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.cat_bar.get_style_context().add_class("filter-bar")
        self.cat_btns = {}
        for cat in CATEGORIES:
            btn = Gtk.Button(label=cat)
            btn.get_style_context().add_class("cat-btn")
            btn.cat = cat
            btn.connect("clicked", self._on_category)
            if cat == self._active_category:
                btn.get_style_context().add_class("cat-btn-active")
            self.cat_bar.pack_start(btn, False, False, 0)
            self.cat_btns[cat] = btn
        root.pack_start(self.cat_bar, False, False, 0)

        # ── App list ─────────────────────────────────────────────────────────
        self.app_scroll = Gtk.ScrolledWindow()
        self.app_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.app_list = Gtk.ListBox()
        self.app_list.get_style_context().add_class("app-list")
        self.app_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self.app_scroll.add(self.app_list)
        root.pack_start(self.app_scroll, True, True, 0)

        # ── Donation strip ───────────────────────────────────────────────────
        don = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        don.get_style_context().add_class("donation-strip")
        don_lbl = Gtk.Label(label="☕  Si SpectrOS t'és útil, considera fer una donació a ArCom Corporation per mantenir el projecte actiu.")
        don_lbl.get_style_context().add_class("donation-lbl")
        don_lbl.set_halign(Gtk.Align.START)
        don_btn = Gtk.Button(label="💚  Donar 5 €")
        don_btn.get_style_context().add_class("donation-btn")
        don_btn.connect("clicked", lambda b: webbrowser.open("https://arcom.cat/donar"))
        don.pack_start(don_lbl, True, True, 0)
        don.pack_end(don_btn, False, False, 0)
        root.pack_start(don, False, False, 0)

        # ── Status bar ───────────────────────────────────────────────────────
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        status_box.get_style_context().add_class("shop-status")
        self.status_lbl = Gtk.Label(label="")
        self.status_lbl.get_style_context().add_class("shop-status-lbl")
        self.status_lbl.set_halign(Gtk.Align.START)
        status_box.pack_start(self.status_lbl, True, True, 0)
        root.pack_start(status_box, False, False, 0)

    # ── Population ────────────────────────────────────────────────────────────

    def _populate(self):
        # Clear
        for child in self.app_list.get_children():
            self.app_list.remove(child)

        apps = CATALOG.get(self._active_section, [])
        count = 0
        for app in apps:
            if self._active_category != "Totes" and app["category"] != self._active_category:
                continue
            if self._search_query and self._search_query.lower() not in app["name"].lower() \
                    and self._search_query.lower() not in app["desc"].lower():
                continue
            card = AppCard(app)
            self.app_list.add(card)
            count += 1

        total = len(apps)
        self.status_lbl.set_text(
            f"{count} de {total} aplicacions  ·  Secció: {self._active_section}"
        )
        self.app_list.show_all()

    # ── Events ────────────────────────────────────────────────────────────────

    def _on_section(self, btn):
        for b in self.section_btns.values():
            b.get_style_context().remove_class("section-tab-active")
        btn.get_style_context().add_class("section-tab-active")
        self._active_section = btn.section
        self._active_category = "Totes"
        for b in self.cat_btns.values():
            b.get_style_context().remove_class("cat-btn-active")
        self.cat_btns["Totes"].get_style_context().add_class("cat-btn-active")
        self._populate()

    def _on_category(self, btn):
        for b in self.cat_btns.values():
            b.get_style_context().remove_class("cat-btn-active")
        btn.get_style_context().add_class("cat-btn-active")
        self._active_category = btn.cat
        self._populate()

    def _on_search(self, entry):
        self._search_query = entry.get_text()
        self._populate()


# ── Application ───────────────────────────────────────────────────────────────

class ShopApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.arcom.spectros.shop")

    def do_activate(self):
        ShopWindow(self).show()


if __name__ == "__main__":
    ShopApp().run()
