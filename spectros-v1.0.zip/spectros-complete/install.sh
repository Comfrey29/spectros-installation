#!/bin/sh
# ═══════════════════════════════════════════════════════════════════
#  SpectrOS — Instal·lador complet
#  ArCom Corporation
#
#  Què fa aquest script:
#   1. Instal·la paquets FreeBSD necessaris (GTK3, XFCE, LightDM...)
#   2. Copia les 4 apps de SpectrOS
#   3. Posa les icones al menú i a l'escriptori XFCE
#   4. Instal·la la splash de boot (Plymouth, fons blanc + barra)
#   5. Instal·la la pantalla de login (LightDM amb tema SpectrOS)
#   6. Configura XFCE perquè arrenqui sempre en encendre la PC
#   7. Activa tot a rc.conf perquè sigui permanent
#
#  Com usar-lo:
#   sudo sh install.sh
# ═══════════════════════════════════════════════════════════════════

set -e
SCRIPT_DIR="$(dirname "$(realpath "$0")")"

# ── Colors de terminal ────────────────────────────────────────────
G='\033[0;32m'; B='\033[0;34m'; Y='\033[1;33m'
R='\033[0;31m'; C='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

ok()   { printf "  ${G}✔${NC}  %s\n" "$1"; }
warn() { printf "  ${Y}⚠${NC}  %s\n" "$1"; }
err()  { printf "  ${R}✘${NC}  %s\n" "$1"; exit 1; }
step() { printf "\n${B}${BOLD}── Pas %s: %s${NC}\n" "$1" "$2"; }

# ── Capçalera ────────────────────────────────────────────────────
clear
printf "${B}${BOLD}"
printf "╔══════════════════════════════════════════════════════╗\n"
printf "║           SpectrOS — Instal·lador complet            ║\n"
printf "║                 ArCom Corporation                    ║\n"
printf "║                      v1.0                           ║\n"
printf "╚══════════════════════════════════════════════════════╝\n"
printf "${NC}\n"
printf "Aquest script configurarà SpectrOS completament:\n"
printf "  apps · icones escriptori · splash boot · login · XFCE\n\n"

# ── Comprovar root ────────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
    err "Cal executar com a root: sudo sh install.sh"
fi

# Detectar usuari real (el que ha fet sudo)
REAL_USER="${SUDO_USER:-}"
if [ -z "$REAL_USER" ]; then
    printf "${Y}Introduïu el nom de l'usuari principal (no root): ${NC}"
    read -r REAL_USER
fi
REAL_HOME="$(eval echo "~${REAL_USER}")"

if [ -z "$REAL_USER" ] || [ ! -d "$REAL_HOME" ]; then
    err "Usuari '$REAL_USER' no trobat o directori home inexistent."
fi
ok "Usuari: $REAL_USER  →  $REAL_HOME"


# ════════════════════════════════════════════════════════════════
# PAS 1 — Paquets FreeBSD
# ════════════════════════════════════════════════════════════════
step 1 "Instal·lant paquets FreeBSD necessaris"

pkg_install() {
    if ! pkg info "$1" >/dev/null 2>&1; then
        printf "  Instal·lant %s...\n" "$1"
        pkg install -y "$1" >/dev/null 2>&1 && ok "$1" || warn "$1 no disponible, continuant"
    else
        ok "$1 (ja instal·lat)"
    fi
}

pkg_install python3
pkg_install py39-gobject3
pkg_install gtk3
pkg_install xfce
pkg_install xfce4-goodies
pkg_install lightdm
pkg_install lightdm-webkit2-greeter
pkg_install dbus
pkg_install xdg-utils

# Plymouth (opcional, pot no estar al repo)
PLYMOUTH_OK=false
if pkg install -y plymouth >/dev/null 2>&1; then
    ok "plymouth"
    PLYMOUTH_OK=true
else
    warn "Plymouth no disponible al repositori. El boot serà silenciós sense splash gràfica."
fi


# ════════════════════════════════════════════════════════════════
# PAS 2 — Apps SpectrOS
# ════════════════════════════════════════════════════════════════
step 2 "Instal·lant les 4 apps de SpectrOS"

APP_DEST="/usr/local/bin/spectros"
mkdir -p "$APP_DEST"

for app in spectros-config spectros-filemanager spectros-shop spectros-updater; do
    src="$SCRIPT_DIR/apps/$app/$app.py"
    if [ -f "$src" ]; then
        cp "$src" "$APP_DEST/$app.py"
        chmod 755 "$APP_DEST/$app.py"
        ok "$app.py  →  $APP_DEST/"
    else
        warn "No trobat: $src"
    fi
done

# version.json (per a l'Updater de GitHub)
cp "$SCRIPT_DIR/apps/version.json" "$APP_DEST/version.json"
ok "version.json  →  $APP_DEST/"


# ════════════════════════════════════════════════════════════════
# PAS 3 — Icones al menú i a l'escriptori XFCE
# ════════════════════════════════════════════════════════════════
step 3 "Configurant icones al menú XFCE i a l'escriptori"

MENU_DIR="/usr/local/share/applications"
DESKTOP_DIR="$REAL_HOME/Desktop"
mkdir -p "$MENU_DIR" "$DESKTOP_DIR"

for app in spectros-config spectros-filemanager spectros-shop spectros-updater; do
    src="$SCRIPT_DIR/apps/$app.desktop"
    if [ -f "$src" ]; then
        # Menú d'aplicacions
        cp "$src" "$MENU_DIR/$app.desktop"
        chmod 644 "$MENU_DIR/$app.desktop"

        # Escriptori
        cp "$src" "$DESKTOP_DIR/$app.desktop"
        chmod 755 "$DESKTOP_DIR/$app.desktop"
        chown "$REAL_USER" "$DESKTOP_DIR/$app.desktop"

        # Marcar com a "de confiança" perquè XFCE no mostri el diàleg
        # (evita el popup "Untrusted launcher")
        if command -v gio >/dev/null 2>&1; then
            su -m "$REAL_USER" -c \
                "gio set '$DESKTOP_DIR/$app.desktop' metadata::trusted true" 2>/dev/null || true
        fi

        ok "$app.desktop  →  menú + escriptori"
    else
        warn "No trobat: $src"
    fi
done

# Actualitzar base de dades del menú
update-desktop-database "$MENU_DIR" 2>/dev/null || true


# ════════════════════════════════════════════════════════════════
# PAS 4 — Splash de boot (Plymouth)
# ════════════════════════════════════════════════════════════════
step 4 "Instal·lant splash de boot SpectrOS (Plymouth)"

if [ "$PLYMOUTH_OK" = true ]; then
    THEME_DEST="/usr/local/share/plymouth/themes/spectros"
    mkdir -p "$THEME_DEST"
    cp "$SCRIPT_DIR/boot/plymouth/spectros/spectros.plymouth" "$THEME_DEST/"
    cp "$SCRIPT_DIR/boot/plymouth/spectros/spectros.script"   "$THEME_DEST/"
    ok "Tema copiat a $THEME_DEST"

    # Activar el tema
    if command -v plymouth-set-default-theme >/dev/null 2>&1; then
        plymouth-set-default-theme spectros
        ok "Tema 'spectros' activat"
    else
        PLYM_CONF="/usr/local/etc/plymouth/plymouthd.conf"
        mkdir -p "$(dirname "$PLYM_CONF")"
        printf '[Daemon]\nTheme=spectros\nShowDelay=0\n' > "$PLYM_CONF"
        ok "Tema configurat a $PLYM_CONF"
    fi
else
    warn "Saltant Plymouth (no instal·lat)"
fi


# ════════════════════════════════════════════════════════════════
# PAS 5 — Pantalla de login (LightDM + tema SpectrOS)
# ════════════════════════════════════════════════════════════════
step 5 "Instal·lant pantalla de login LightDM"

# Tema web (HTML/CSS/JS)
WEBKIT_THEME_DEST="/usr/local/share/lightdm-webkit2-greeter/themes/spectros-greeter"
mkdir -p "$WEBKIT_THEME_DEST"
cp "$SCRIPT_DIR/boot/lightdm/spectros-greeter/index.html" "$WEBKIT_THEME_DEST/"
ok "Tema login copiat a $WEBKIT_THEME_DEST"

# Configuració del greeter
LDMCONF_DIR="/usr/local/etc/lightdm"
mkdir -p "$LDMCONF_DIR"
cp "$SCRIPT_DIR/boot/lightdm/lightdm-webkit2-greeter.conf" "$LDMCONF_DIR/"
cp "$SCRIPT_DIR/boot/lightdm/lightdm.conf"                 "$LDMCONF_DIR/"
ok "Configuració LightDM aplicada a $LDMCONF_DIR"


# ════════════════════════════════════════════════════════════════
# PAS 6 — XFCE com a sessió permanent
# ════════════════════════════════════════════════════════════════
step 6 "Configurant XFCE perquè arrenqui sempre"

# .xinitrc (per si s'usa startx manualment)
cat > "$REAL_HOME/.xinitrc" <<'XINITRC'
#!/bin/sh
exec startxfce4
XINITRC
chown "$REAL_USER" "$REAL_HOME/.xinitrc"
chmod 755 "$REAL_HOME/.xinitrc"
ok ".xinitrc configurat"

# Configuració de sessió XFCE
XFCE_XML_DIR="$REAL_HOME/.config/xfce4/xfconf/xfce-perchannel-xml"
mkdir -p "$XFCE_XML_DIR"
cp "$SCRIPT_DIR/boot/xfce/xfce4-session.xml" "$XFCE_XML_DIR/"
chown -R "$REAL_USER" "$REAL_HOME/.config"
ok "Sessió XFCE configurada"


# ════════════════════════════════════════════════════════════════
# PAS 7 — rc.conf i loader.conf (permanent a cada arrencada)
# ════════════════════════════════════════════════════════════════
step 7 "Activant serveis a rc.conf (permanent)"

# Funció per afegir o actualitzar una línia a rc.conf
set_rc() {
    key="$1"; val="$2"; file="/etc/rc.conf"
    if grep -q "^${key}=" "$file" 2>/dev/null; then
        sed -i '' "s|^${key}=.*|${key}=${val}|" "$file"
    else
        echo "${key}=${val}" >> "$file"
    fi
}

set_rc dbus_enable    '"YES"'   # Necessari per XFCE i LightDM
set_rc hald_enable    '"YES"'   # Detecció de maquinari
set_rc moused_enable  '"YES"'   # Ratolí a la consola
set_rc lightdm_enable '"YES"'   # ← Arrenca LightDM (i XFCE) a cada boot

if [ "$PLYMOUTH_OK" = true ]; then
    set_rc plymouth_enable '"YES"'
fi

ok "dbus, hald, moused, lightdm  →  activats a /etc/rc.conf"

# Boot silenciós (menys missatges de kernel visibles)
set_loader() {
    key="$1"; val="$2"; file="/boot/loader.conf"
    if grep -q "^${key}=" "$file" 2>/dev/null; then
        sed -i '' "s|^${key}=.*|${key}=${val}|" "$file"
    else
        echo "${key}=${val}" >> "$file"
    fi
}

set_loader boot_mute '"YES"'
ok "Boot silenciós activat a /boot/loader.conf"


# ════════════════════════════════════════════════════════════════
# RESUM FINAL
# ════════════════════════════════════════════════════════════════
printf "\n${G}${BOLD}"
printf "╔══════════════════════════════════════════════════════╗\n"
printf "║          SpectrOS instal·lat correctament! ✔         ║\n"
printf "╚══════════════════════════════════════════════════════╝\n"
printf "${NC}\n"

printf "${BOLD}Flux d'arrencada configurat:${NC}\n\n"
printf "  ${C}①${NC} PC encesa\n"
if [ "$PLYMOUTH_OK" = true ]; then
printf "  ${C}②${NC} Splash SpectrOS  (blanc + barra de progrés)\n"
else
printf "  ${C}②${NC} Boot silenciós  (Plymouth no disponible)\n"
fi
printf "  ${C}③${NC} Login SpectrOS   (LightDM, usuari + contrasenya)\n"
printf "  ${C}④${NC} Escriptori XFCE  (amb les 4 apps d'ArCom)\n\n"

printf "${BOLD}Apps instal·lades a:${NC}  /usr/local/bin/spectros/\n"
printf "${BOLD}Icones a:${NC}             ~/Desktop/  i  menú XFCE\n\n"

printf "${Y}Per aplicar tots els canvis, reinicieu:${NC}\n"
printf "  ${B}sudo reboot${NC}\n\n"

printf "${Y}Si hi ha algun problema amb LightDM:${NC}\n"
printf "  ${B}sudo service lightdm status${NC}\n"
printf "  ${B}sudo sysrc lightdm_enable=NO && sudo reboot${NC}  (per tornar enrere)\n\n"
