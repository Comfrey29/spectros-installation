# SpectrOS v1.0 — ArCom Corporation

## Com instal·lar-ho

1. Descomprimeix el zip
2. Obre un terminal a la carpeta
3. Executa:

```sh
sudo sh install.sh
sudo reboot
```

Ja està. Quan l'ordinador torni a encendre's veuràs SpectrOS completament configurat.

---

## Contingut del paquet

```
install.sh                        ← L'únic script que cal executar

apps/
  spectros-config/                ← Panell de configuració del sistema
  spectros-filemanager/           ← Gestor de fitxers 3 panells
  spectros-shop/                  ← Botiga ArCom + FreeBSD OSS
  spectros-updater/               ← Actualitzador via GitHub
  *.desktop                       ← Icones per al menú i l'escriptori
  version.json                    ← Puja'l a Comfrey29/spectros-updater

boot/
  plymouth/spectros/              ← Splash de boot (blanc, barra animada)
  lightdm/spectros-greeter/       ← Pantalla de login personalitzada
  lightdm/*.conf                  ← Configuració LightDM
  xfce/xfce4-session.xml          ← Sessió XFCE per defecte
```

## Flux d'arrencada

```
PC encesa
  → Splash SpectrOS (blanc + barra de progrés)
  → Login SpectrOS (usuari + contrasenya)
  → Escriptori XFCE amb les 4 apps d'ArCom
```
