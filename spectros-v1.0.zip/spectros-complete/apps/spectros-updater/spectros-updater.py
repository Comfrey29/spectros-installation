#!/usr/bin/env python3
# spectros-updater.py — SpectrOS Update Manager
# ArCom Corporation — FreeBSD base — GTK3
# Conecta amb: https://github.com/Comfrey29/spectros-updater

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Pango
import threading
import subprocess
import json
import urllib.request
import urllib.error
import os
import datetime

# ── Constants ─────────────────────────────────────────────────────────────────
CURRENT_VERSION = "1.0.0"
GITHUB_REPO     = "Comfrey29/spectros-updater"
VERSION_URL     = f"https://raw.githubusercontent.com/{GITHUB_REPO}/main/version.json"
APP_TITLE       = "SpectrOS Updater"
# ──────────────────────────────────────────────────────────────────────────────


def version_tuple(v):
    """Converteix '1.2.3' en (1, 2, 3) per comparar."""
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except Exception:
        return (0,)


class UpdaterWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=f"🔄 {APP_TITLE}")
        self.set_default_size(640, 480)
        self.set_resizable(False)

        self._build_ui()
        self._apply_css()

    # ── UI ────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(root)

        # ── Header ──────────────────────────────────────────────────────────
        header_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        header_box.get_style_context().add_class("header-bar")
        header_box.set_margin_bottom(0)

        title_lbl = Gtk.Label(label="SpectrOS Update Manager")
        title_lbl.get_style_context().add_class("title-label")
        subtitle_lbl = Gtk.Label(label=f"ArCom Corporation · FreeBSD base · v{CURRENT_VERSION}")
        subtitle_lbl.get_style_context().add_class("subtitle-label")

        header_box.pack_start(title_lbl, False, False, 0)
        header_box.pack_start(subtitle_lbl, False, False, 0)
        root.pack_start(header_box, False, False, 0)

        # ── Status card ─────────────────────────────────────────────────────
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        card.get_style_context().add_class("card")

        # Version row
        ver_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)

        cur_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        cur_title = Gtk.Label(label="Versió actual")
        cur_title.get_style_context().add_class("col-title")
        cur_title.set_halign(Gtk.Align.START)
        self.cur_ver_lbl = Gtk.Label(label=CURRENT_VERSION)
        self.cur_ver_lbl.get_style_context().add_class("ver-badge")
        self.cur_ver_lbl.set_halign(Gtk.Align.START)
        cur_col.pack_start(cur_title, False, False, 0)
        cur_col.pack_start(self.cur_ver_lbl, False, False, 0)

        sep = Gtk.Label(label="→")
        sep.get_style_context().add_class("arrow-sep")

        new_col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        new_title = Gtk.Label(label="Última versió disponible")
        new_title.get_style_context().add_class("col-title")
        new_title.set_halign(Gtk.Align.START)
        self.new_ver_lbl = Gtk.Label(label="—")
        self.new_ver_lbl.get_style_context().add_class("ver-badge-new")
        self.new_ver_lbl.set_halign(Gtk.Align.START)
        new_col.pack_start(new_title, False, False, 0)
        new_col.pack_start(self.new_ver_lbl, False, False, 0)

        ver_row.pack_start(cur_col, False, False, 0)
        ver_row.pack_start(sep, False, False, 0)
        ver_row.pack_start(new_col, False, False, 0)
        card.pack_start(ver_row, False, False, 0)

        # Status label
        self.status_lbl = Gtk.Label(label="Premeu 'Comprovar actualitzacions' per iniciar.")
        self.status_lbl.get_style_context().add_class("status-label")
        self.status_lbl.set_halign(Gtk.Align.START)
        self.status_lbl.set_line_wrap(True)
        card.pack_start(self.status_lbl, False, False, 0)

        # Progress bar (hidden by default)
        self.progress = Gtk.ProgressBar()
        self.progress.get_style_context().add_class("update-progress")
        self.progress.set_no_show_all(True)
        self.progress.hide()
        card.pack_start(self.progress, False, False, 0)

        root.pack_start(card, False, False, 0)

        # ── Changelog ───────────────────────────────────────────────────────
        cl_lbl = Gtk.Label(label="Changelog")
        cl_lbl.get_style_context().add_class("section-title")
        cl_lbl.set_halign(Gtk.Align.START)
        cl_lbl.set_margin_start(20)
        cl_lbl.set_margin_top(8)
        root.pack_start(cl_lbl, False, False, 0)

        cl_scroll = Gtk.ScrolledWindow()
        cl_scroll.set_margin_start(20)
        cl_scroll.set_margin_end(20)
        cl_scroll.set_margin_bottom(8)
        cl_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)

        self.changelog_buf = Gtk.TextBuffer()
        self.changelog_view = Gtk.TextView(buffer=self.changelog_buf)
        self.changelog_view.set_editable(False)
        self.changelog_view.set_cursor_visible(False)
        self.changelog_view.set_wrap_mode(Gtk.WrapMode.WORD)
        self.changelog_view.get_style_context().add_class("changelog-view")
        cl_scroll.add(self.changelog_view)
        root.pack_start(cl_scroll, True, True, 0)

        # ── System updates section ───────────────────────────────────────────
        sys_lbl = Gtk.Label(label="Actualitzacions de sistema (FreeBSD)")
        sys_lbl.get_style_context().add_class("section-title")
        sys_lbl.set_halign(Gtk.Align.START)
        sys_lbl.set_margin_start(20)
        sys_lbl.set_margin_top(4)
        root.pack_start(sys_lbl, False, False, 0)

        sys_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        sys_row.set_margin_start(20)
        sys_row.set_margin_end(20)
        sys_row.set_margin_bottom(12)

        self.pkg_btn = Gtk.Button(label="📦  pkg upgrade")
        self.pkg_btn.get_style_context().add_class("sys-btn")
        self.pkg_btn.connect("clicked", self._run_pkg_upgrade)

        self.fbsd_btn = Gtk.Button(label="🔐  freebsd-update fetch install")
        self.fbsd_btn.get_style_context().add_class("sys-btn")
        self.fbsd_btn.connect("clicked", self._run_freebsd_update)

        sys_row.pack_start(self.pkg_btn, True, True, 0)
        sys_row.pack_start(self.fbsd_btn, True, True, 0)
        root.pack_start(sys_row, False, False, 0)

        # ── Bottom buttons ───────────────────────────────────────────────────
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        btn_box.get_style_context().add_class("btn-bar")

        self.last_check_lbl = Gtk.Label(label="Última comprovació: mai")
        self.last_check_lbl.get_style_context().add_class("last-check")

        self.check_btn = Gtk.Button(label="🔍  Comprovar actualitzacions")
        self.check_btn.get_style_context().add_class("primary-btn")
        self.check_btn.connect("clicked", self._on_check)

        btn_box.pack_start(self.last_check_lbl, True, True, 0)
        btn_box.pack_end(self.check_btn, False, False, 0)
        root.pack_start(btn_box, False, False, 0)

        self.show_all()

    def _apply_css(self):
        css = b"""
        window { background-color: #1e2127; }

        .header-bar {
            background: linear-gradient(135deg, #1a3a5c 0%, #0d2137 100%);
            padding: 18px 24px 16px 24px;
            border-bottom: 2px solid #2e6da4;
        }
        .title-label {
            font-size: 20px;
            font-weight: bold;
            color: #e8eaf6;
            letter-spacing: 1px;
        }
        .subtitle-label {
            font-size: 11px;
            color: #7a9cbf;
        }

        .card {
            background-color: #252932;
            border: 1px solid #2e3540;
            border-radius: 8px;
            margin: 16px 20px 8px 20px;
            padding: 16px;
        }
        .col-title {
            font-size: 10px;
            color: #7a8a9a;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .ver-badge {
            font-size: 18px;
            font-weight: bold;
            color: #78909c;
        }
        .ver-badge-new {
            font-size: 18px;
            font-weight: bold;
            color: #4fc3f7;
        }
        .arrow-sep {
            font-size: 22px;
            color: #2e6da4;
            margin-top: 12px;
        }
        .status-label {
            font-size: 12px;
            color: #90a4ae;
            margin-top: 4px;
        }
        .update-progress {
            margin-top: 6px;
        }
        progress, trough {
            min-height: 6px;
            border-radius: 3px;
        }
        progress {
            background-color: #2e6da4;
        }

        .section-title {
            font-size: 11px;
            font-weight: bold;
            color: #546e7a;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 4px;
        }

        .changelog-view {
            background-color: #1a1e24;
            color: #90a4ae;
            font-family: monospace;
            font-size: 12px;
            padding: 10px;
            border-radius: 4px;
            min-height: 80px;
        }

        .sys-btn {
            background-color: #2a3240;
            color: #90caf9;
            border: 1px solid #37474f;
            border-radius: 6px;
            padding: 8px;
            font-size: 12px;
        }
        .sys-btn:hover {
            background-color: #1e3a5f;
            color: #e3f2fd;
        }

        .btn-bar {
            background-color: #1a1e24;
            border-top: 1px solid #2e3540;
            padding: 12px 20px;
        }
        .last-check {
            font-size: 11px;
            color: #546e7a;
        }
        .primary-btn {
            background: linear-gradient(135deg, #1565c0, #0d47a1);
            color: #e3f2fd;
            border: none;
            border-radius: 6px;
            padding: 10px 20px;
            font-weight: bold;
            font-size: 13px;
        }
        .primary-btn:hover {
            background: linear-gradient(135deg, #1976d2, #1565c0);
        }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            self.get_screen(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    # ── Actions ───────────────────────────────────────────────────────────────

    def _on_check(self, btn):
        self.check_btn.set_sensitive(False)
        self.status_lbl.set_text("Connectant amb GitHub...")
        self.progress.show()
        self.progress.pulse()
        self._start_pulse()
        threading.Thread(target=self._fetch_version, daemon=True).start()

    def _start_pulse(self):
        def pulse():
            if self.progress.get_visible():
                self.progress.pulse()
                return True
            return False
        GLib.timeout_add(120, pulse)

    def _fetch_version(self):
        try:
            req = urllib.request.Request(
                VERSION_URL,
                headers={"User-Agent": f"SpectrOS-Updater/{CURRENT_VERSION}"}
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode())
            GLib.idle_add(self._on_version_received, data)
        except urllib.error.URLError as e:
            GLib.idle_add(self._on_fetch_error, f"Error de xarxa: {e.reason}")
        except json.JSONDecodeError:
            GLib.idle_add(self._on_fetch_error, "El fitxer version.json del repositori no és vàlid.")
        except Exception as e:
            GLib.idle_add(self._on_fetch_error, str(e))

    def _on_version_received(self, data):
        self.progress.hide()
        self.check_btn.set_sensitive(True)

        remote_ver  = data.get("version", "0.0.0")
        changelog   = data.get("changelog", "(sense notes)")
        release_date = data.get("date", "")

        self.new_ver_lbl.set_text(remote_ver)
        self.changelog_buf.set_text(f"v{remote_ver}  {release_date}\n\n{changelog}")

        now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
        self.last_check_lbl.set_text(f"Última comprovació: {now}")

        if version_tuple(remote_ver) > version_tuple(CURRENT_VERSION):
            self.status_lbl.set_markup(
                f'<span foreground="#81c784"><b>Nova versió disponible: {remote_ver}</b></span>'
            )
            self._show_update_dialog(remote_ver, changelog)
        else:
            self.status_lbl.set_markup(
                '<span foreground="#a5d6a7">✔  El sistema està actualitzat.</span>'
            )

    def _on_fetch_error(self, msg):
        self.progress.hide()
        self.check_btn.set_sensitive(True)
        self.status_lbl.set_markup(f'<span foreground="#ef9a9a">✘  {msg}</span>')

    def _show_update_dialog(self, version, changelog):
        dlg = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Nova versió disponible: {version}"
        )
        dlg.format_secondary_text(
            f"Changelog:\n{changelog[:400]}\n\nVoleu descarregar l'actualització ara?"
        )
        response = dlg.run()
        dlg.destroy()
        if response == Gtk.ResponseType.YES:
            import webbrowser
            webbrowser.open(f"https://github.com/{GITHUB_REPO}/releases/latest")

    def _run_pkg_upgrade(self, btn):
        self._run_terminal_cmd(["pkexec", "pkg", "upgrade", "-y"], "pkg upgrade")

    def _run_freebsd_update(self, btn):
        self._run_terminal_cmd(
            ["pkexec", "sh", "-c", "freebsd-update fetch && freebsd-update install"],
            "freebsd-update"
        )

    def _run_terminal_cmd(self, cmd, label):
        dlg = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Executar: {label}"
        )
        dlg.format_secondary_text(
            "Aquesta acció requereix privilegis de superusuari (pkexec/sudo).\nContinueu?"
        )
        resp = dlg.run()
        dlg.destroy()
        if resp == Gtk.ResponseType.YES:
            self.status_lbl.set_text(f"Executant {label}...")
            threading.Thread(
                target=self._exec_cmd, args=(cmd, label), daemon=True
            ).start()

    def _exec_cmd(self, cmd, label):
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300
            )
            out = result.stdout[-1000:] if result.stdout else result.stderr[-1000:]
            GLib.idle_add(
                self.status_lbl.set_markup,
                f'<span foreground="#a5d6a7">✔  {label} completat.</span>'
            )
            GLib.idle_add(self.changelog_buf.set_text, f"[{label} output]\n\n{out}")
        except subprocess.TimeoutExpired:
            GLib.idle_add(self._on_fetch_error, f"{label}: timeout (5 min)")
        except Exception as e:
            GLib.idle_add(self._on_fetch_error, str(e))


class UpdaterApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.arcom.spectros.updater")

    def do_activate(self):
        win = UpdaterWindow(self)
        win.show()


if __name__ == "__main__":
    app = UpdaterApp()
    app.run()
