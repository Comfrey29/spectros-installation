#!/usr/bin/env python3
# spectros-config.py — SpectrOS Configuration Panel
# ArCom Corporation — FreeBSD base — GTK3
# Pestanyes: General / Sistema / Usuaris / WIFI / Bluetooth / Updater

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Pango
import subprocess
import threading
import os
import socket
import platform


# ── Helpers ───────────────────────────────────────────────────────────────────

def run_cmd(cmd, timeout=8):
    """Executa comanda i retorna stdout o cadena buida."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip()
    except Exception:
        return ""


def label_row(key, value):
    """Retorna un Gtk.Box horitzontal clau→valor."""
    box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
    k = Gtk.Label(label=key)
    k.get_style_context().add_class("info-key")
    k.set_halign(Gtk.Align.START)
    k.set_size_request(160, -1)
    v = Gtk.Label(label=value or "—")
    v.get_style_context().add_class("info-val")
    v.set_halign(Gtk.Align.START)
    v.set_selectable(True)
    v.set_line_wrap(True)
    box.pack_start(k, False, False, 0)
    box.pack_start(v, True, True, 0)
    return box


def section_label(text):
    lbl = Gtk.Label(label=text)
    lbl.get_style_context().add_class("section-head")
    lbl.set_halign(Gtk.Align.START)
    lbl.set_margin_top(12)
    lbl.set_margin_bottom(4)
    return lbl


# ── Tabs ─────────────────────────────────────────────────────────────────────

class TabGeneral(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.set_margin_start(20)
        self.set_margin_end(20)
        self.set_margin_top(16)

        hostname = socket.gethostname()
        uname = platform.uname()
        uptime = run_cmd(["uptime", "-p"]) or run_cmd(["uptime"])
        timezone = run_cmd(["date", "+%Z"])
        locale_out = os.environ.get("LANG", "—")

        self.pack_start(section_label("Sistema"), False, False, 0)
        for k, v in [
            ("Nom de host", hostname),
            ("Sistema operatiu", f"{uname.system} {uname.release}"),
            ("Versió del kernel", uname.version[:60] if uname.version else "—"),
            ("Arquitectura", uname.machine),
            ("Node", uname.node),
            ("Temps actiu", uptime),
        ]:
            self.pack_start(label_row(k, v), False, False, 0)

        self.pack_start(section_label("Localització"), False, False, 0)
        for k, v in [
            ("Zona horària", timezone),
            ("Locale", locale_out),
            ("Data i hora", run_cmd(["date"])),
        ]:
            self.pack_start(label_row(k, v), False, False, 0)

        # Hostname editor
        self.pack_start(section_label("Canviar nom de host"), False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.host_entry = Gtk.Entry()
        self.host_entry.set_text(hostname)
        self.host_entry.set_size_request(240, -1)
        apply_btn = Gtk.Button(label="Aplicar")
        apply_btn.get_style_context().add_class("apply-btn")
        apply_btn.connect("clicked", self._apply_hostname)
        row.pack_start(self.host_entry, False, False, 0)
        row.pack_start(apply_btn, False, False, 0)
        self.pack_start(row, False, False, 0)

        self.show_all()

    def _apply_hostname(self, btn):
        new = self.host_entry.get_text().strip()
        if new:
            run_cmd(["pkexec", "hostname", new])
            self._info(f"Nom de host canviat a: {new}\n(Cal reiniciar per fer-ho permanent)")

    def _info(self, msg):
        dlg = Gtk.MessageDialog(message_type=Gtk.MessageType.INFO,
                                buttons=Gtk.ButtonsType.OK, text=msg)
        dlg.run(); dlg.destroy()


class TabSistema(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.set_margin_start(20); self.set_margin_end(20); self.set_margin_top(16)

        # CPU
        cpu_info = run_cmd(["sysctl", "-n", "hw.model"]) or platform.processor()
        ncpu = run_cmd(["sysctl", "-n", "hw.ncpu"])
        # RAM (FreeBSD: hw.physmem en bytes)
        physmem = run_cmd(["sysctl", "-n", "hw.physmem"])
        ram_gb = f"{int(physmem)/(1024**3):.1f} GB" if physmem.isdigit() else "—"
        # Disk
        df_out = run_cmd(["df", "-h", "/"])

        self.pack_start(section_label("Processador"), False, False, 0)
        for k, v in [("Model", cpu_info), ("Nuclis / CPUs", ncpu)]:
            self.pack_start(label_row(k, v), False, False, 0)

        self.pack_start(section_label("Memòria RAM"), False, False, 0)
        self.pack_start(label_row("Memòria física", ram_gb), False, False, 0)

        self.pack_start(section_label("Espai en disc (/)"), False, False, 0)
        df_lbl = Gtk.Label(label=df_out or "—")
        df_lbl.get_style_context().add_class("mono-block")
        df_lbl.set_halign(Gtk.Align.START)
        df_lbl.set_selectable(True)
        self.pack_start(df_lbl, False, False, 0)

        # Services
        self.pack_start(section_label("Serveis"), False, False, 0)
        services = ["sshd", "ntpd", "dhclient", "dbus", "hald"]
        for svc in services:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            lbl = Gtk.Label(label=svc)
            lbl.get_style_context().add_class("info-key")
            lbl.set_size_request(120, -1)
            lbl.set_halign(Gtk.Align.START)
            sw = Gtk.Switch()
            active = bool(run_cmd(["service", svc, "status"]))
            sw.set_active(active)
            sw.svc = svc
            sw.connect("state-set", self._toggle_service)
            row.pack_start(lbl, False, False, 0)
            row.pack_start(sw, False, False, 0)
            self.pack_start(row, False, False, 0)

        self.show_all()

    def _toggle_service(self, sw, state):
        action = "start" if state else "stop"
        threading.Thread(
            target=lambda: run_cmd(["pkexec", "service", sw.svc, action]),
            daemon=True
        ).start()


class TabUsuaris(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.set_margin_start(20); self.set_margin_end(20); self.set_margin_top(16)

        self.pack_start(section_label("Usuaris del sistema"), False, False, 0)

        # User list from /etc/passwd (uid >= 1000, no system)
        users = self._get_users()

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_size_request(-1, 180)

        store = Gtk.ListStore(str, str, str, str)
        for u in users:
            store.append(u)

        tv = Gtk.TreeView(model=store)
        tv.get_style_context().add_class("user-list")
        for i, col in enumerate(["Usuari", "UID", "Shell", "Home"]):
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(col, renderer, text=i)
            column.set_min_width(100)
            tv.append_column(column)

        scroll.add(tv)
        self.pack_start(scroll, False, False, 0)

        # Add user
        self.pack_start(section_label("Crear nou usuari"), False, False, 0)
        grid = Gtk.Grid(column_spacing=8, row_spacing=6)

        grid.attach(Gtk.Label(label="Nom d'usuari:"), 0, 0, 1, 1)
        self.new_user_entry = Gtk.Entry(); self.new_user_entry.set_placeholder_text("ex: joan")
        grid.attach(self.new_user_entry, 1, 0, 1, 1)

        grid.attach(Gtk.Label(label="Shell:"), 0, 1, 1, 1)
        self.shell_combo = Gtk.ComboBoxText()
        for sh in ["/bin/sh", "/bin/csh", "/bin/tcsh", "/usr/local/bin/bash"]:
            self.shell_combo.append_text(sh)
        self.shell_combo.set_active(0)
        grid.attach(self.shell_combo, 1, 1, 1, 1)

        add_btn = Gtk.Button(label="➕  Crear usuari")
        add_btn.get_style_context().add_class("apply-btn")
        add_btn.connect("clicked", self._add_user)
        grid.attach(add_btn, 1, 2, 1, 1)

        self.pack_start(grid, False, False, 0)

        # Change password
        self.pack_start(section_label("Canviar contrasenya"), False, False, 0)
        pw_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.pw_user = Gtk.Entry(); self.pw_user.set_placeholder_text("Usuari")
        self.pw_entry = Gtk.Entry(); self.pw_entry.set_placeholder_text("Nova contrasenya")
        self.pw_entry.set_visibility(False)
        pw_btn = Gtk.Button(label="Canviar")
        pw_btn.get_style_context().add_class("apply-btn")
        pw_btn.connect("clicked", self._change_pw)
        pw_row.pack_start(self.pw_user, False, False, 0)
        pw_row.pack_start(self.pw_entry, False, False, 0)
        pw_row.pack_start(pw_btn, False, False, 0)
        self.pack_start(pw_row, False, False, 0)

        self.show_all()

    def _get_users(self):
        users = []
        try:
            with open("/etc/passwd") as f:
                for line in f:
                    parts = line.strip().split(":")
                    if len(parts) >= 7:
                        uid = parts[2]
                        if uid.isdigit() and int(uid) >= 1000:
                            users.append((parts[0], uid, parts[6], parts[5]))
        except Exception:
            users = [(os.environ.get("USER", "—"), "—", "—", os.path.expanduser("~"))]
        return users or [(os.environ.get("USER", "—"), "—", "—", os.path.expanduser("~"))]

    def _add_user(self, btn):
        user = self.new_user_entry.get_text().strip()
        shell = self.shell_combo.get_active_text()
        if user:
            run_cmd(["pkexec", "pw", "useradd", "-n", user, "-s", shell, "-m"])
            self._info(f"Usuari '{user}' creat (si no hi havia errors de permisos).")

    def _change_pw(self, btn):
        user = self.pw_user.get_text().strip()
        pw = self.pw_entry.get_text()
        if user and pw:
            proc = subprocess.Popen(
                ["pkexec", "passwd", user],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            proc.communicate(input=f"{pw}\n{pw}\n".encode())
            self._info(f"Contrasenya de '{user}' canviada.")

    def _info(self, msg):
        dlg = Gtk.MessageDialog(message_type=Gtk.MessageType.INFO,
                                buttons=Gtk.ButtonsType.OK, text=msg)
        dlg.run(); dlg.destroy()


class TabWifi(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.set_margin_start(20); self.set_margin_end(20); self.set_margin_top(16)

        self.pack_start(section_label("Interfícies de xarxa"), False, False, 0)

        # ifconfig summary
        ifconfig = run_cmd(["ifconfig"])
        mono = Gtk.Label(label=ifconfig[:800] if ifconfig else "No s'ha pogut obtenir ifconfig.")
        mono.get_style_context().add_class("mono-block")
        mono.set_halign(Gtk.Align.START)
        mono.set_selectable(True)
        mono.set_line_wrap(True)
        self.pack_start(mono, False, False, 0)

        self.pack_start(section_label("Xarxes WiFi disponibles"), False, False, 0)

        # Scan button + list
        scan_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.iface_entry = Gtk.Entry()
        self.iface_entry.set_placeholder_text("Interfície (ex: wlan0)")
        self.iface_entry.set_size_request(140, -1)
        scan_btn = Gtk.Button(label="🔍  Escanejar")
        scan_btn.get_style_context().add_class("apply-btn")
        scan_btn.connect("clicked", self._scan)
        scan_row.pack_start(self.iface_entry, False, False, 0)
        scan_row.pack_start(scan_btn, False, False, 0)
        self.pack_start(scan_row, False, False, 0)

        self.scan_lbl = Gtk.Label(label="(Introduïu la interfície i premeu Escanejar)")
        self.scan_lbl.get_style_context().add_class("mono-block")
        self.scan_lbl.set_halign(Gtk.Align.START)
        self.scan_lbl.set_selectable(True)
        self.scan_lbl.set_line_wrap(True)
        self.pack_start(self.scan_lbl, False, False, 0)

        # Connect
        self.pack_start(section_label("Connectar a xarxa WiFi"), False, False, 0)
        grid = Gtk.Grid(column_spacing=8, row_spacing=6)
        grid.attach(Gtk.Label(label="SSID:"), 0, 0, 1, 1)
        self.ssid_entry = Gtk.Entry(); self.ssid_entry.set_placeholder_text("NomXarxa")
        grid.attach(self.ssid_entry, 1, 0, 1, 1)
        grid.attach(Gtk.Label(label="Contrasenya:"), 0, 1, 1, 1)
        self.psk_entry = Gtk.Entry(); self.psk_entry.set_visibility(False)
        grid.attach(self.psk_entry, 1, 1, 1, 1)
        conn_btn = Gtk.Button(label="Connectar")
        conn_btn.get_style_context().add_class("apply-btn")
        conn_btn.connect("clicked", self._connect_wifi)
        grid.attach(conn_btn, 1, 2, 1, 1)
        self.pack_start(grid, False, False, 0)

        self.show_all()

    def _scan(self, btn):
        iface = self.iface_entry.get_text().strip() or "wlan0"
        self.scan_lbl.set_text("Escanejant...")
        threading.Thread(target=self._do_scan, args=(iface,), daemon=True).start()

    def _do_scan(self, iface):
        out = run_cmd(["ifconfig", iface, "list", "scan"])
        GLib.idle_add(self.scan_lbl.set_text, out or "Cap xarxa trobada (o permisos insuficients).")

    def _connect_wifi(self, btn):
        ssid = self.ssid_entry.get_text().strip()
        psk  = self.psk_entry.get_text()
        iface = self.iface_entry.get_text().strip() or "wlan0"
        if ssid:
            # Escriu wpa_supplicant i reinicia interfície
            wpa_conf = f"""
network={{
    ssid="{ssid}"
    psk="{psk}"
}}
"""
            try:
                wpa_path = "/tmp/spectros_wpa.conf"
                with open(wpa_path, "w") as f:
                    f.write(wpa_conf)
                run_cmd(["pkexec", "cp", wpa_path, "/etc/wpa_supplicant.conf"])
                run_cmd(["pkexec", "ifconfig", iface, "up"])
                self._info(f"Connectant a '{ssid}'...")
            except Exception as e:
                self._info(str(e))

    def _info(self, msg):
        dlg = Gtk.MessageDialog(message_type=Gtk.MessageType.INFO,
                                buttons=Gtk.ButtonsType.OK, text=msg)
        dlg.run(); dlg.destroy()


class TabBluetooth(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.set_margin_start(20); self.set_margin_end(20); self.set_margin_top(16)

        self.pack_start(section_label("Estat Bluetooth"), False, False, 0)

        # hccontrol / btvhci status
        bt_status = run_cmd(["hccontrol", "-n", "ubt0hci", "read_bd_addr"]) or \
                    run_cmd(["bluetooth", "show"]) or "No s'ha detectat adaptador Bluetooth."

        status_lbl = Gtk.Label(label=bt_status)
        status_lbl.get_style_context().add_class("mono-block")
        status_lbl.set_halign(Gtk.Align.START)
        status_lbl.set_selectable(True)
        self.pack_start(status_lbl, False, False, 0)

        # Enable/Disable
        self.pack_start(section_label("Activar / Desactivar"), False, False, 0)
        ctrl_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        on_btn = Gtk.Button(label="🔵  Activar Bluetooth")
        on_btn.get_style_context().add_class("apply-btn")
        on_btn.connect("clicked", lambda b: run_cmd(["pkexec", "service", "bluetooth", "start"]))
        off_btn = Gtk.Button(label="⚫  Desactivar Bluetooth")
        off_btn.get_style_context().add_class("apply-btn")
        off_btn.connect("clicked", lambda b: run_cmd(["pkexec", "service", "bluetooth", "stop"]))
        ctrl_row.pack_start(on_btn, False, False, 0)
        ctrl_row.pack_start(off_btn, False, False, 0)
        self.pack_start(ctrl_row, False, False, 0)

        # Scan devices
        self.pack_start(section_label("Dispositius detectats"), False, False, 0)
        scan_btn = Gtk.Button(label="🔍  Escanejar dispositius")
        scan_btn.get_style_context().add_class("apply-btn")
        scan_btn.connect("clicked", self._scan)
        self.pack_start(scan_btn, False, False, 0)

        self.bt_results = Gtk.Label(label="(Premeu Escanejar per buscar dispositius)")
        self.bt_results.get_style_context().add_class("mono-block")
        self.bt_results.set_halign(Gtk.Align.START)
        self.bt_results.set_selectable(True)
        self.bt_results.set_line_wrap(True)
        self.pack_start(self.bt_results, False, False, 0)

        # Pair
        self.pack_start(section_label("Emparellar dispositiu"), False, False, 0)
        pair_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.pair_entry = Gtk.Entry()
        self.pair_entry.set_placeholder_text("Adreça BD (ex: 00:1A:7D:DA:71:14)")
        self.pair_entry.set_size_request(240, -1)
        pair_btn = Gtk.Button(label="Emparellar")
        pair_btn.get_style_context().add_class("apply-btn")
        pair_btn.connect("clicked", self._pair)
        pair_row.pack_start(self.pair_entry, False, False, 0)
        pair_row.pack_start(pair_btn, False, False, 0)
        self.pack_start(pair_row, False, False, 0)

        self.show_all()

    def _scan(self, btn):
        self.bt_results.set_text("Escanejant... (pot trigar uns segons)")
        threading.Thread(target=self._do_scan, daemon=True).start()

    def _do_scan(self):
        out = run_cmd(["hccontrol", "-n", "ubt0hci", "inquiry"], timeout=15) or \
              "Cap dispositiu trobat (o adaptador no disponible)."
        GLib.idle_add(self.bt_results.set_text, out)

    def _pair(self, btn):
        addr = self.pair_entry.get_text().strip()
        if addr:
            run_cmd(["pkexec", "hccontrol", "-n", "ubt0hci", "create_connection", addr])


class TabUpdater(Gtk.Box):
    """Pestanya d'accés ràpid a l'Updater des de Config."""
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.set_margin_start(20); self.set_margin_end(20); self.set_margin_top(20)

        info = Gtk.Label(label=(
            "Des d'aquí podeu llançar l'eina d'actualització de SpectrOS,\n"
            "comprovar l'estat del sistema i actualitzar paquets FreeBSD."
        ))
        info.set_halign(Gtk.Align.START)
        info.set_line_wrap(True)
        info.get_style_context().add_class("info-val")
        self.pack_start(info, False, False, 0)

        # Version info
        pkg_ver = run_cmd(["pkg", "-v"]) or "—"
        self.pack_start(section_label("Informació de paquets"), False, False, 0)
        self.pack_start(label_row("Versió de pkg", pkg_ver), False, False, 0)
        self.pack_start(label_row("SpectrOS versió", "1.0.0"), False, False, 0)

        # Buttons
        btn_grid = Gtk.Grid(column_spacing=10, row_spacing=8)
        btn_grid.set_margin_top(12)

        actions = [
            ("🔄  Llançar Updater", self._launch_updater),
            ("📦  pkg upgrade", self._pkg_upgrade),
            ("🔐  freebsd-update fetch", self._fbsd_update),
            ("📋  pkg audit", self._pkg_audit),
        ]
        for i, (label, cb) in enumerate(actions):
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("apply-btn")
            btn.connect("clicked", cb)
            btn_grid.attach(btn, i % 2, i // 2, 1, 1)

        self.pack_start(btn_grid, False, False, 0)

        self.output_lbl = Gtk.Label(label="")
        self.output_lbl.get_style_context().add_class("mono-block")
        self.output_lbl.set_halign(Gtk.Align.START)
        self.output_lbl.set_selectable(True)
        self.output_lbl.set_line_wrap(True)
        self.pack_start(self.output_lbl, False, False, 0)

        self.show_all()

    def _launch_updater(self, btn):
        subprocess.Popen(["python3", "/usr/local/bin/spectros/spectros-updater.py"])

    def _pkg_upgrade(self, btn):
        self._run_async(["pkexec", "pkg", "upgrade", "-n"])

    def _fbsd_update(self, btn):
        self._run_async(["pkexec", "freebsd-update", "fetch"])

    def _pkg_audit(self, btn):
        self._run_async(["pkg", "audit", "-F"])

    def _run_async(self, cmd):
        self.output_lbl.set_text("Executant...")
        threading.Thread(target=self._do_run, args=(cmd,), daemon=True).start()

    def _do_run(self, cmd):
        out = run_cmd(cmd, timeout=60) or "(sense sortida)"
        GLib.idle_add(self.output_lbl.set_text, out[:600])


# ── Main Window ───────────────────────────────────────────────────────────────

class ConfigWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="⚙️  SpectrOS Config")
        self.set_default_size(760, 580)

        self._apply_css()

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(root)

        # Header
        hdr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        hdr.get_style_context().add_class("app-header")
        title = Gtk.Label(label="⚙️  SpectrOS Configuration")
        title.get_style_context().add_class("app-title")
        hdr.pack_start(title, False, False, 0)
        root.pack_start(hdr, False, False, 0)

        # Notebook
        nb = Gtk.Notebook()
        nb.get_style_context().add_class("main-nb")
        nb.set_tab_pos(Gtk.PositionType.LEFT)

        tabs = [
            ("🌐  General",    TabGeneral),
            ("💻  Sistema",    TabSistema),
            ("👤  Usuaris",    TabUsuaris),
            ("📶  WIFI",       TabWifi),
            ("🔵  Bluetooth",  TabBluetooth),
            ("🔄  Updater",    TabUpdater),
        ]
        for label, TabClass in tabs:
            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            tab_widget = TabClass()
            scroll.add(tab_widget)
            tab_lbl = Gtk.Label(label=label)
            tab_lbl.set_halign(Gtk.Align.START)
            tab_lbl.set_size_request(130, -1)
            nb.append_page(scroll, tab_lbl)

        root.pack_start(nb, True, True, 0)
        self.show_all()

    def _apply_css(self):
        css = b"""
        window { background-color: #1e2127; }

        .app-header {
            background: linear-gradient(135deg, #1a3a5c 0%, #0d2137 100%);
            padding: 14px 20px;
            border-bottom: 2px solid #2e6da4;
        }
        .app-title {
            font-size: 17px;
            font-weight: bold;
            color: #e8eaf6;
        }

        .main-nb tab {
            background-color: #1a1e24;
            color: #7a8a9a;
            padding: 8px 4px;
            border-right: 2px solid #2e3540;
        }
        .main-nb tab:checked {
            background-color: #252932;
            color: #90caf9;
            border-right: 2px solid #2e6da4;
        }
        .main-nb {
            background-color: #252932;
        }

        .section-head {
            font-size: 11px;
            font-weight: bold;
            color: #2e6da4;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding-bottom: 2px;
            border-bottom: 1px solid #2e3540;
        }
        .info-key {
            font-size: 12px;
            color: #546e7a;
        }
        .info-val {
            font-size: 12px;
            color: #b0bec5;
        }
        .mono-block {
            font-family: monospace;
            font-size: 11px;
            color: #78909c;
            background-color: #1a1e24;
            padding: 8px;
            border-radius: 4px;
        }
        .apply-btn {
            background: linear-gradient(135deg, #1565c0, #0d47a1);
            color: #e3f2fd;
            border: none;
            border-radius: 5px;
            padding: 6px 14px;
            font-size: 12px;
        }
        .apply-btn:hover {
            background: linear-gradient(135deg, #1976d2, #1565c0);
        }

        .user-list {
            background-color: #1a1e24;
            color: #b0bec5;
            font-size: 12px;
        }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            self.get_screen(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )


class ConfigApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.arcom.spectros.config")

    def do_activate(self):
        ConfigWindow(self).show()


if __name__ == "__main__":
    ConfigApp().run()
